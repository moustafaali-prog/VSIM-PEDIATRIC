# University of Babylon Pediatric VCS — v1.5.0

This release converts the 11-patient directory into runtime-loadable scenario packages while preserving the project's no-hallucination/source-traceability policy.

## Important status
This is an engineering integration build, not a clinically validated production release.

## Scenario package policy
- Baseline facts come from FILE-05.
- Timed events are only encoded where FILE-05 provides explicit timing.
- Medication/order execution is disabled until validated order sets are approved.
- The UI/runtime may display source facts without treating them as independently validated clinical standards.
