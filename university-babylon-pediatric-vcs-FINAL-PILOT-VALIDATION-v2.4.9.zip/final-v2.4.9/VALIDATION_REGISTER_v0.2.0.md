# Validation Register — v0.2.0

| Component | Source basis | Status |
|---|---|---|
| CJMM weights | File 04 | SOURCE_DEFINED |
| Final performance domains | File 07 | SOURCE_DEFINED |
| 8-stage workflow | File 07 | SOURCE_DEFINED |
| Scenario registry | File 05 | SOURCE_DEFINED |
| Medication dose logic | Project files + external validation required | NOT_IMPLEMENTED |
| Drug PK/PD response constants | File 02; production use requires clinical validation | NOT_IMPLEMENTED |
| Fowler fixed SpO2/RR bonus | File 06; conflicts with the validated-engine design | NOT_IMPLEMENTED |
| Universal silent-chest threshold | Not supported as a universal rule | NOT_IMPLEMENTED |
