# Clinical Validation Register v0.1.0

The seven project files are the project specification. External clinical guidance is used to verify—not silently replace—project values.

## Decisions
- High Fowler: preserve as an interaction state; remove fixed SpO2/RR bonuses from the clinical engine.
- Silent chest: scenario-specific event, not a universal SpO2 threshold.
- Scoring: File 04 CJMM profile and File 07 performance domains remain separate reporting dimensions.
- Medication parameters: no unvalidated dose, concentration, EC50, Emax, half-life or fixed response is hard-coded.
- Every clinical parameter must carry provenance and validation status.

## External verification anchors
WHO pediatric SCD guideline 2026; GINA Strategy Report 2026; SCCM pediatric sepsis guidance 2026; IDSA/PIDS pediatric CAP guideline 2026; Brain Trauma Foundation pediatric severe TBI guideline; INACSL Healthcare Simulation Standards.

This repository is an educational software baseline, not a clinical order set.
