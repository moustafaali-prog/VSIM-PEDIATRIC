# University of Babylon Pediatric VCS — v0.2.0

## What was added
- Scenario event engine with deterministic time/action triggers.
- Separate CJMM scoring profile using the six File-04 weights.
- Separate final performance score using File-07 domain weights.
- Auditable action log with timestamps.
- SBAR report generator.
- Debrief report generator.
- Explicit separation of source-defined scoring systems.

## Clinical-safety boundary
This implementation intentionally does **not** hard-code medication dose instructions or unvalidated pharmacologic response constants. Medication actions should resolve against a future institutionally validated order-set layer.

## Source traceability
- File 01: architecture and clinical pipeline.
- File 04: CJMM weights and safety framework.
- File 05: scenario registry and scenario-specific data.
- File 07: eight-stage workflow and final performance-domain weights.

## Known specification conflict retained for resolution
File 04 and File 07 use different scoring structures. They are therefore modeled as two separate dimensions rather than silently merged.
