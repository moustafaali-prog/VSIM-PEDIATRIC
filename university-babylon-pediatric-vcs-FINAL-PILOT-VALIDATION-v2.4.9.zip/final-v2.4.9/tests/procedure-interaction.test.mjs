import test from 'node:test';
import assert from 'node:assert/strict';

// Contract tests kept dependency-free so they can run even before npm install.
test('procedure interaction contract: clinical action occurs only after completion', () => {
  const events = [];
  let progress = 0;
  const update = dt => {
    progress = Math.min(1, progress + dt / 2);
    if (progress === 1) events.push('complete');
  };
  assert.deepEqual(events, []);
  update(1);
  assert.deepEqual(events, []);
  update(1);
  assert.deepEqual(events, ['complete']);
});

test('procedure interaction contract: target/action mismatch is rejected', () => {
  const registry = { auscultate_lungs: 'clickable_chest', hand_hygiene: 'clickable_handwash' };
  assert.equal(registry.auscultate_lungs === 'clickable_handwash', false);
});
