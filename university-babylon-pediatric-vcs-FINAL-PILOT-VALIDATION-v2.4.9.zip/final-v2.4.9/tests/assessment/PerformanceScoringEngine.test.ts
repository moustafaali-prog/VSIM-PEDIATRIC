import {strict as assert} from 'node:assert'; import test from 'node:test'; import {PerformanceScoringEngine} from '../../src/assessment/PerformanceScoringEngine';
test('maximum score is 100',()=>{const e=new PerformanceScoringEngine();for(const k of ['safety','assessment','interventions','emergency','communication'] as const)e.setDomainScore(k,e.weights[k]);assert.equal(e.total(),100);});
