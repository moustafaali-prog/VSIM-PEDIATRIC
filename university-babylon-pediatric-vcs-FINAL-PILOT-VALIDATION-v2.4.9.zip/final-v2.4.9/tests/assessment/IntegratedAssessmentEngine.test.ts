import test from "node:test";
import assert from "node:assert/strict";
import { IntegratedAssessmentEngine } from "../../src/assessment/IntegratedAssessmentEngine";

test("integrated assessment awards accepted criteria once", () => {
  const e = new IntegratedAssessmentEngine("sarah-davis");
  e.recordAction({ actionId:"hand_hygiene", simulationTimeSeconds:0, accepted:true });
  e.recordAction({ actionId:"position_knee_chest", simulationTimeSeconds:2, accepted:true });
  e.recordAction({ actionId:"position_knee_chest", simulationTimeSeconds:3, accepted:true });
  const s=e.snapshot();
  assert.equal(s.performance.safety,2);
  assert.equal(s.performance.emergency,6);
  assert.equal(s.completedCriteria.filter(x=>x==="SARAH-KNEE").length,1);
});

test("blocked actions do not score", () => {
  const e = new IntegratedAssessmentEngine("rana-kadhim");
  e.recordAction({ actionId:"apply_oxygen", simulationTimeSeconds:1, accepted:false, reason:"Safety gate" });
  assert.equal(e.snapshot().performanceTotal,0);
});
