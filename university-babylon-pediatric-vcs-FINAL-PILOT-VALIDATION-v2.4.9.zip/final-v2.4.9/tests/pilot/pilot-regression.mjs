import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const DIST = path.join(ROOT, '.regression-dist');
const BASELINE = path.join(ROOT, 'baselines/pilot-regression-baseline.json');
const UPDATE = process.argv.includes('--update-baseline');

function run(cmd, args) {
  const r = spawnSync(cmd, args, { cwd: ROOT, encoding: 'utf8' });
  if (r.status !== 0) {
    process.stderr.write(r.stdout || '');
    process.stderr.write(r.stderr || '');
    throw new Error(`${cmd} ${args.join(' ')} failed with exit ${r.status}`);
  }
  return r.stdout;
}

rmSync(DIST, { recursive: true, force: true });
run('tsc', ['-p', 'tsconfig.regression.json', '--pretty', 'false']);
writeFileSync(path.join(DIST, 'package.json'), '{"type":"commonjs"}\n');

const harness = await import(pathToFile(path.join(DIST, 'pilot/PilotSimulationHarness.js')));
const packages = await import(pathToFile(path.join(DIST, 'scenarios/ScenarioPackage.js')));

function pathToFile(p) { return new URL(`file://${p}`).href; }

const scenarios = packages.OperationalScenarioPackages.map(s => s.id);
const devices = ['DESKTOP', 'TABLET', 'PHONE'];
const faults = ['NONE', 'SKIP_HAND_HYGIENE', 'SKIP_PATIENT_ID', 'SKIP_ALLERGY_CHECK', 'WRONG_SEQUENCE'];

function stableState(state) {
  return {
    timeSeconds: state.timeSeconds,
    position: state.position,
    flags: Object.fromEntries(Object.entries(state.flags).sort()),
    audit: state.audit,
    respiratory: state.respiratory,
    cardiovascular: state.cardiovascular,
    pain: state.pain,
    hydration: state.hydration,
    temperatureC: state.temperatureC,
  };
}

function normalize(result) {
  return {
    scenarioId: result.scenarioId,
    device: result.device,
    fault: result.fault,
    completed: result.completed,
    finalTimeSeconds: result.finalTimeSeconds,
    acceptedActions: result.acceptedActions,
    rejectedActions: result.rejectedActions,
    completion: result.completion,
    observedState: stableState(result.observedState),
    auditCount: result.auditCount,
  };
}

function runTimedProbe(scenarioId, device, seconds) {
  return normalize(harness.runPilotScenario(scenarioId, device, 'NONE', [
    ...harness.defaultPilotSteps('NONE'),
    { seconds },
  ]));
}

const results = [];
for (const scenarioId of scenarios) {
  for (const device of devices) {
    for (const fault of faults) {
      results.push(normalize(harness.runPilotScenario(scenarioId, device, fault)));
    }
  }
}

// Timed-event probes exercise every currently specified time-triggered event.
const timed = [
  ['BABYLON-PED-01', 180],
  ['BABYLON-PED-01', 360],
  ['VSIM-PED-02', 240],
];
for (const [scenarioId, seconds] of timed) {
  for (const device of devices) results.push({ ...runTimedProbe(scenarioId, device, seconds), probe: `TIMED_${seconds}s` });
}

const payload = JSON.stringify(results);
const fingerprint = createHash('sha256').update(payload).digest('hex');
const current = { schemaVersion: 1, suiteVersion: '2.4.7', generatedAt: new Date().toISOString(), caseCount: results.length, fingerprint, results };

if (UPDATE || !existsSync(BASELINE)) {
  mkdirSync(path.dirname(BASELINE), { recursive: true });
  writeFileSync(BASELINE, JSON.stringify(current, null, 2) + '\n');
  console.log(`pilot-regression: baseline ${UPDATE ? 'UPDATED' : 'CREATED'} (${results.length} cases, ${fingerprint})`);
  process.exit(0);
}

const baseline = JSON.parse(readFileSync(BASELINE, 'utf8'));
const expected = JSON.stringify(baseline.results);
const actual = JSON.stringify(results);
if (expected !== actual) {
  const first = Math.min(baseline.results.length, results.length);
  let index = 0;
  while (index < first && JSON.stringify(baseline.results[index]) === JSON.stringify(results[index])) index++;
  console.error(`pilot-regression: FAIL — regression detected at case index ${index}`);
  console.error(`baseline cases=${baseline.caseCount}, current cases=${results.length}`);
  console.error(`baseline fingerprint=${baseline.fingerprint}`);
  console.error(`current fingerprint=${fingerprint}`);
  if (index < first) {
    console.error('--- expected'); console.error(JSON.stringify(baseline.results[index], null, 2));
    console.error('--- actual'); console.error(JSON.stringify(results[index], null, 2));
  }
  console.error('If this is an intentional, reviewed change, regenerate the baseline with: npm run pilot:regression:update');
  process.exit(1);
}

console.log(`pilot-regression: PASS — ${results.length} deterministic cases match baseline (${fingerprint})`);
