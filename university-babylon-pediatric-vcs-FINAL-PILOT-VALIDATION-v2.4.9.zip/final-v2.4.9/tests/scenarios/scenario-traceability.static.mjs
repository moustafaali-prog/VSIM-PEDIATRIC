import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.cwd());
const catalog = fs.readFileSync(path.join(root, 'src/scenarios/ScenarioCatalog.ts'), 'utf8');
const pkg = fs.readFileSync(path.join(root, 'src/scenarios/ScenarioPackage.ts'), 'utf8');
const map = fs.readFileSync(path.join(root, 'src/scenarios/ScenarioClinicalMap.ts'), 'utf8');

const ids = [...catalog.matchAll(/id:\s*"([^"]+)"/g)].map(m => m[1]);
assert.equal(ids.length, 11, 'catalog must contain exactly 11 scenarios');
assert.equal(new Set(ids).size, 11, 'scenario ids must be unique');
assert.equal((pkg.match(/makeScenario\(ScenarioCatalog\[/g) ?? []).length, 11, 'all 11 catalog entries must have packages');
for (const id of ids) assert.match(map, new RegExp(`"${id}"\\s*:`), `clinical map missing ${id}`);
assert.match(pkg, /executableMedicationLogic:\s*false/, 'medication execution must remain disabled');
assert.match(pkg, /clinicalValidationRequired:\s*true/, 'clinical validation gate must remain enabled');
console.log('scenario-traceability.static: PASS');
