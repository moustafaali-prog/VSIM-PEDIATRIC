import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const file = new URL('../../src/scenarios/MedicationOrderValidationRegistry.ts', import.meta.url);
const text = fs.readFileSync(file, 'utf8');

test('medication/order registry covers all 11 scenario IDs', () => {
  const ids = [...text.matchAll(/scenarioId:"([^"]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, 11);
  assert.equal(new Set(ids).size, 11);
});

test('medication execution is explicitly locked', () => {
  assert.match(text, /executable:false/);
  assert.match(text, /MEDICATION_ORDER_EXECUTION_MUST_REMAIN_LOCKED/);
});

test('required clinical order checks are explicit', () => {
  for (const key of ['indication','route','dose/order parameters','timing/frequency','contraindications/allergies','monitoring requirements','expected response','local institutional compatibility']) {
    assert.match(text, new RegExp(key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  }
});
