import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const root = new URL('../../', import.meta.url);
const registry = fs.readFileSync(new URL('src/scenarios/ClinicalValidationRegistry.ts', root), 'utf8');
const packageSource = fs.readFileSync(new URL('src/scenarios/ScenarioPackage.ts', root), 'utf8');

test('clinical validation registry covers all 11 project scenarios', () => {
  const expected = [
    'rana-kadhim','charlie-snow','brittany-long','eva-madison','jackson-weber',
    'sabrina-vasquez','ethan-williams','olivia-jones','sarah-davis','tommy-evans','peyton-harris'
  ];
  for (const id of expected) assert.match(registry, new RegExp(`"${id}"`));
});

test('medication execution remains disabled until explicit validation', () => {
  assert.match(packageSource, /executableMedicationLogic:\s*false/);
  assert.match(registry, /elementType:\s*"MEDICATION"/);
  assert.match(registry, /status:\s*"REQUIRES_REVISION"/);
  assert.match(registry, /executable:\s*false/);
});

test('no scenario is treated as clinically approved by default', () => {
  assert.doesNotMatch(registry, /status:\s*"SME_APPROVED"/);
});
