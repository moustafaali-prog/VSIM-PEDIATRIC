import test from "node:test";
import assert from "node:assert/strict";
import { OperationalScenarioPackages, getOperationalScenario } from "../../src/scenarios/ScenarioPackage";

test("all 11 project scenarios are operationally loadable", () => {
  assert.equal(OperationalScenarioPackages.length, 11);
  for (const s of OperationalScenarioPackages) {
    assert.equal(s.clinicalValidationRequired, true);
    assert.equal(s.executableMedicationLogic, false);
    assert.equal(s.validationStatus, "PENDING_VALIDATION");
    assert.ok(s.sourceFacts.length > 0);
  }
});

test("timed events are only the explicitly timed source events", () => {
  const rana = getOperationalScenario("BABYLON-PED-01");
  const charlie = getOperationalScenario("VSIM-PED-02");
  assert.deepEqual(rana?.events.map(e => e.trigger.type === "time" ? e.trigger.atSeconds : null), [180, 360]);
  assert.deepEqual(charlie?.events.map(e => e.trigger.type === "time" ? e.trigger.atSeconds : null), [240]);
});
