import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const manifest = readFileSync('src/audio/ClinicalAudioManifest.ts', 'utf8');
const registry = readFileSync('src/audio/AudioValidationRegistry.ts', 'utf8');
const synchronizer = readFileSync('src/audio/ClinicalAudioSynchronizer.ts', 'utf8');

test('audio validation registry is conservative by default', () => {
  const cues = [...manifest.matchAll(/'([A-Z_]+)'\|/g)].map(m => m[1]);
  assert.equal(new Set(cues).size, 7);
  assert.match(registry, /technicalQA: 'PENDING'/);
  assert.match(registry, /clinicalQA: 'PENDING'/);
  assert.match(registry, /status: 'SOURCE_REGISTERED'/);
  assert.match(registry, /licenseStatus: asset\.licenseCleared \? 'CLEARED' : 'NOT_CLEARED'/);
});

test('audio synchronizer remains presentation-only', () => {
  assert.match(synchronizer, /deriveClinicalPresentation\(state\)/);
  assert.doesNotMatch(synchronizer, /physiology|setClinicalState|mutate|dispatchAction/);
});

console.log('Audio validation registry: 2/2 PASS');
