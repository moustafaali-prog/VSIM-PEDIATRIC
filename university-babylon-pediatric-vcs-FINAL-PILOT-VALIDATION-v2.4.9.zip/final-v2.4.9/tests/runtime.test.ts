import assert from "node:assert/strict";
import test from "node:test";
import { SimulationRuntime } from "../src/core/SimulationRuntime";
import { BrittanyLongCore } from "../src/scenarios/BrittanyLongCore";

test("runtime blocks patient action before safety gates", () => {
  const runtime = new SimulationRuntime(BrittanyLongCore);
  assert.equal(runtime.perform("initial_vitals"), false);
});

test("runtime completes safety gates and accepts clinical action", () => {
  const runtime = new SimulationRuntime(BrittanyLongCore);
  assert.equal(runtime.perform("hand_hygiene"), true);
  assert.equal(runtime.perform("identify_patient"), true);
  assert.equal(runtime.perform("check_allergies"), true);
  assert.equal(runtime.perform("initial_vitals"), true);
});

test("runtime time advances deterministically", () => {
  const runtime = new SimulationRuntime(BrittanyLongCore);
  runtime.start();
  const before = runtime.snapshot().timeSeconds;
  runtime.tick(1);
  assert.equal(runtime.snapshot().timeSeconds, before + 1);
});
