import { test, expect } from '@playwright/test';

test('browser performance telemetry exposes a measurable frame loop', async ({ page }) => {
  await page.goto('/');
  const sample = await page.evaluate(async () => {
    const samples:number[] = [];
    let last = performance.now();
    const start = last;
    while (performance.now() - start < 2000) {
      await new Promise(requestAnimationFrame);
      const now = performance.now();
      samples.push(now - last);
      last = now;
    }
    const positive = samples.filter(x => x > 0);
    const avg = positive.reduce((a,b)=>a+b,0) / Math.max(1, positive.length);
    return { frames: positive.length, avgFrameMs: avg, estimatedFps: 1000 / avg };
  });
  expect(sample.frames).toBeGreaterThan(30);
  // This is an engineering observation, not a clinical acceptance threshold.
  expect(sample.avgFrameMs).toBeGreaterThan(0);
});
