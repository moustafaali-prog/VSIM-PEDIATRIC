import { test, expect } from '@playwright/test';

test('application mounts and exposes the clinical simulation shell', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByTestId('pediatric-vcs-app')).toBeVisible();
  await expect(page.getByTestId('simulation-title')).toHaveText('University of Babylon — Pediatric VCS');
  await expect(page.getByTestId('simulation-scene')).toBeVisible();
  await expect(page.getByTestId('simulation-panel')).toBeVisible();
  await expect(page.getByTestId('device-profile')).toContainText('Device:');
  await expect(page.getByRole('button', { name: 'Hand hygiene' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Identify patient' })).toBeVisible();
});

test('safety gate blocks initial vitals before required safety actions', async ({ page }) => {
  await page.goto('/');
  const before = await page.locator('pre').nth(0).textContent();
  await page.getByRole('button', { name: 'Initial vitals' }).click();
  await page.waitForTimeout(100);
  const after = await page.locator('pre').nth(0).textContent();
  expect(after).toContain('SpO₂:');
  expect(before).not.toBeNull();
});

test('mobile layout remains within viewport without horizontal overflow', async ({ page }) => {
  await page.goto('/');
  const metrics = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    clientWidth: document.documentElement.clientWidth,
  }));
  expect(metrics.scrollWidth).toBeLessThanOrEqual(metrics.clientWidth + 1);
});
