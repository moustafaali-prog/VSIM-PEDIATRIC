import test from "node:test";
import assert from "node:assert/strict";
import { EndToEndSession } from "../../src/core/EndToEndSession";
import { getOperationalScenario } from "../../src/scenarios/ScenarioPackage";

test("E2E session projects source patient into EHR without inventing orders", () => {
  const scenario = getOperationalScenario("BABYLON-PED-01")!;
  const session = new EndToEndSession(scenario);
  const s = session.snapshot();
  assert.equal(s.ehr.patient.displayName, "Rana Kadhim");
  assert.equal(s.ehr.patient.weightKg, 24);
  assert.deepEqual(s.ehr.orders, []);
  assert.equal(s.completion.readyForDebrief, false);
});

test("E2E session records runtime vitals in EHR projection", () => {
  const session = new EndToEndSession(getOperationalScenario("VSIM-PED-03")!);
  session.start();
  const s = session.tick(1);
  assert.equal(s.ehr.vitals.length, 1);
  assert.equal(s.ehr.vitals[0]?.heartRate, 135);
  assert.equal(s.ehr.vitals[0]?.oxygenSaturation, 91);
});

test("completion remains blocked until all workflow requirements are accepted", () => {
  const session = new EndToEndSession(getOperationalScenario("VSIM-PED-03")!);
  for (const id of ["hand_hygiene","identify_patient","check_allergies","review_ehr","initial_vitals","pat_assessment","reassess_vitals","document","sbar_handover"] as const) session.perform(id);
  session.setSBAR({situation:"S",background:"B",assessment:"A",recommendation:"R"});
  assert.equal(session.snapshot().completion.readyForDebrief, true);
});
