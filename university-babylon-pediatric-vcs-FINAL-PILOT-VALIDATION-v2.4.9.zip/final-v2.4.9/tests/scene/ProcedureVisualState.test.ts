import assert from "node:assert/strict";
import test from "node:test";
import { IDLE_PROCEDURE_VISUAL } from "../../src/scene/ProcedureVisualState";

test("idle procedure visual state is inert",()=>{assert.equal(IDLE_PROCEDURE_VISUAL.id,null);assert.equal(IDLE_PROCEDURE_VISUAL.phase,"idle");assert.equal(IDLE_PROCEDURE_VISUAL.progress,0);});
