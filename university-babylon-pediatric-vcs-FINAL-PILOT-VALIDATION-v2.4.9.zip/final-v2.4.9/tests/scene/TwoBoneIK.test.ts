import {strict as assert} from 'node:assert'; import test from 'node:test'; import * as THREE from 'three'; import {solveTwoBoneIK} from '../../src/scene/TwoBoneIK';
test('IK target',()=>{const t=new THREE.Vector3(1,1,0);const r=solveTwoBoneIK(new THREE.Vector3(),t,new THREE.Vector3(0,1,0),1,1);assert.ok(r.reachable);assert.ok(r.wrist.distanceTo(t)<1e-9);});
