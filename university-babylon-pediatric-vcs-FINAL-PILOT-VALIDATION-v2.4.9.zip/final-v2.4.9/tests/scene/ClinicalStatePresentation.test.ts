import test from "node:test";
import assert from "node:assert/strict";
import { deriveClinicalPresentation } from "../../src/scene/ClinicalStatePresentation";
import type { ClinicalState } from "../../src/clinical/ClinicalState";

const base: ClinicalState = {
  timeSeconds: 0,
  respiratory: { rate: 48, oxygenSaturation: 86, effort: "severe", airflow: "markedly_reduced" },
  cardiovascular: { heartRate: 144, systolicBP: 108, diastolicBP: 66, capillaryRefillSeconds: 3 },
  pain: { score: 3, scale: "test" },
  hydration: { status: "adequate" },
  temperatureC: 37.6,
  position: "supine",
  flags: { silent_chest: true },
  audit: { handHygieneCompleted: false, patientIdentified: false, allergyCheckCompleted: false },
};

test("presentation is a pure deterministic projection of clinical state", () => {
  const a = deriveClinicalPresentation(base);
  const b = deriveClinicalPresentation(structuredClone(base));
  assert.deepEqual(a, b);
  assert.equal(a.perfusion, "cyanotic");
  assert.equal(a.respiratoryMotionHz, 0.8);
  assert.ok(a.sounds.includes("monitor_alarm"));
  assert.ok(a.sounds.includes("silent_chest"));
});

test("presentation does not mutate clinical state", () => {
  const before = structuredClone(base);
  deriveClinicalPresentation(base);
  assert.deepEqual(base, before);
});
