import assert from "node:assert/strict";
import test from "node:test";
import { deriveTelemetry } from "../../src/ui/TelemetryModel";

const state:any={timeSeconds:0,respiratory:{rate:24,oxygenSaturation:96,effort:"normal",airflow:"normal"},cardiovascular:{heartRate:120,systolicBP:100,diastolicBP:60,capillaryRefillSeconds:2},pain:{score:null,scale:null},hydration:{status:"adequate"},temperatureC:37,position:"supine",flags:{},audit:{handHygieneCompleted:false,patientIdentified:false,allergyCheckCompleted:false}};
test("telemetry derives all four channels from one state",()=>{const a=deriveTelemetry(state); const b=deriveTelemetry(state); assert.deepEqual(a.vitals,b.vitals); assert.equal(a.channels.length,4); assert.deepEqual(a.channels.map(x=>x.samples),b.channels.map(x=>x.samples));});
test("telemetry projection does not mutate clinical state",()=>{const before=JSON.stringify(state); void deriveTelemetry(state); assert.equal(JSON.stringify(state),before);});
