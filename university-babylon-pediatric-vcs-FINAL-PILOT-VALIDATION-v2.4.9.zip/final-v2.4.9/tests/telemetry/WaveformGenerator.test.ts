import {strict as assert} from 'node:assert'; import test from 'node:test'; import {generateWaveform} from '../../src/telemetry/WaveformGenerator';
test('deterministic ECG',()=>assert.deepEqual(generateWaveform('ECG',{heartRate:120}),generateWaveform('ECG',{heartRate:120})));
test('ABP envelope',()=>{const x=generateWaveform('ABP',{systolicBP:110,diastolicBP:70});assert.ok(Math.min(...x.map(v=>v.value))>=70);assert.ok(Math.max(...x.map(v=>v.value))<=110);});
