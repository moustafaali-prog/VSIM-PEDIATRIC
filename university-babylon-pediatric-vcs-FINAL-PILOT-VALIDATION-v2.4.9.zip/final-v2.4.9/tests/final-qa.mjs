import { readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

const read = p => readFileSync(p, 'utf8');
const reg = read('src/scene/InteractionRegistry.ts');
const maps = read('src/scenarios/ScenarioClinicalMap.ts');
const packages = read('src/scenarios/ScenarioPackage.ts');
const catalog = read('src/scenarios/ScenarioCatalog.ts');
const actionTypes = read('src/clinical/ActionTypes.ts');
const procedures = read('src/procedures/ProcedureStateMachine.ts');
const ehr = read('src/ehr/ScenarioEHRBridge.ts');
const completion = read('src/core/SimulationCompletion.ts');
const manifest = read('src/final/BuildManifest.ts');

const errors=[]; const warnings=[];
const fail = msg => errors.push(msg);

const registryActions=[...reg.matchAll(/actionId:\s*"([a-z0-9_]+)"/g)].map(m=>m[1]);
const typeActions=[...actionTypes.matchAll(/"([a-z0-9_]+)"/g)].map(m=>m[1]);
const registryTargets=[...reg.matchAll(/target:\s*"([^"]+)"/g)].map(m=>m[1]);
const procedureIds=[...procedures.matchAll(/'([A-Z_]+)'(?:\||;)/g)].map(m=>m[1]);
const procedureSet=new Set(procedureIds);

if (new Set(registryActions).size !== registryActions.length) fail('DUPLICATE_REGISTRY_ACTION');
for (const a of typeActions) if (!registryActions.includes(a)) fail(`ACTION_WITHOUT_INTERACTION:${a}`);
for (const a of registryActions) if (!typeActions.includes(a)) fail(`INTERACTION_NOT_IN_ACTION_TYPES:${a}`);

const registryDefs=[...reg.matchAll(/\{ actionId: "([a-z0-9_]+)", target: "([^"]+)"(?:, procedure: "([A-Z_]+)")?/g)];
for (const m of registryDefs) if (m[3] && !procedureSet.has(m[3])) fail(`UNKNOWN_PROCEDURE:${m[1]}:${m[3]}`);

const expectedTargets = ['clickable_handwash','clickable_wristband','clickable_monitor','clickable_patient','clickable_chest','clickable_heart','clickable_head','clickable_wrist','clickable_bed','clickable_oxygen','clickable_nebulizer','clickable_glucose','clickable_arm','clickable_suction'];
const equipment=read('src/scene/EquipmentInteraction.ts');
const models=read('src/scene/HighFidelityProceduralModels.ts');
const interactiveTargets=[...equipment.matchAll(/objectName:\s*"([^"]+)"/g)].map(m=>m[1]);
for (const t of registryTargets) {
  if (t.startsWith('ui_')) continue;
  if (!interactiveTargets.includes(t)) fail(`REGISTRY_TARGET_NOT_INTERACTIVE:${t}`);
}
for (const t of expectedTargets) {
  if (!interactiveTargets.includes(t)) fail(`EXPECTED_INTERACTIVE_TARGET_MISSING:${t}`);
}

const catalogCodes=[...catalog.matchAll(/code:\s*"([A-Z0-9-]+)"/g)].map(m=>m[1]);
if (catalogCodes.length !== 11) fail(`SCENARIO_COUNT:${catalogCodes.length}`);
if (new Set(catalogCodes).size !== catalogCodes.length) fail('DUPLICATE_SCENARIO_CODES');
if (!packages.includes('executableMedicationLogic: false')) fail('MEDICATION_EXECUTION_FLAG_NOT_FALSE');
if (!packages.includes('clinicalValidationRequired: true')) fail('CLINICAL_VALIDATION_GATE_MISSING');
const packageCount=(packages.match(/makeScenario\(ScenarioCatalog\[/g)||[]).length;
if (packageCount !== 11) fail(`OPERATIONAL_PACKAGE_COUNT:${packageCount}`);

const criteria=[...maps.matchAll(/\{id:"([A-Z0-9-]+)",actionId:"([a-z0-9_]+)"[^\n]*points:([0-9]+),/g)];
const criterionIds=criteria.map(m=>m[1]);
if (new Set(criterionIds).size !== criterionIds.length) fail('DUPLICATE_CRITERION_IDS');
for (const m of criteria) {
  const [,id,action,points]=m;
  if (!registryActions.includes(action)) fail(`UNMAPPED_CRITERION_ACTION:${id}:${action}`);
  if (Number(points) <= 0) fail(`NON_POSITIVE_CRITERION:${id}:${points}`);
}

const eventActionMatches=[...maps.matchAll(/actionIds:\[([^\]]*)\]/g)];
for (const m of eventActionMatches) {
  for (const a of [...m[1].matchAll(/"([a-z0-9_]+)"/g)].map(x=>x[1])) if (!registryActions.includes(a)) fail(`UNMAPPED_EVENT_ACTION:${a}`);
}

const timed=[...packages.matchAll(/trigger:\{type:"time",atSeconds:([0-9]+)\}/g)].map(m=>Number(m[1]));
if (timed.some(t=>t<0)) fail('NEGATIVE_TIMED_EVENT');
const timedIds=[...packages.matchAll(/\{id:"([A-Z0-9-]+)",once:true,trigger:\{type:"time"/g)].map(m=>m[1]);
if (new Set(timedIds).size !== timedIds.length) fail('DUPLICATE_TIMED_EVENT_IDS');

if (!ehr.includes('sourceSupportedAllergies')) fail('EHR_ALLERGY_PROJECTION_MISSING');
if (!completion.includes('safetyGate') || !completion.includes('sbar')) fail('COMPLETION_GATE_STRUCTURE_INCOMPLETE');
if (!manifest.includes('medicationDoseExecutionRequiresValidatedOrderSet: true')) fail('MEDICATION_VALIDATION_POLICY_MISSING');

execFileSync('node',['tests/scenarios/scenario-traceability.static.mjs'],{stdio:'inherit'});
execFileSync('node',['tests/procedure-interaction.test.mjs'],{stdio:'inherit'});

console.log(JSON.stringify({ok:errors.length===0,errors,warnings,metrics:{actionTypes:typeActions.length,registryActions:registryActions.length,criteria:criteria.length,timedEvents:timed.length,scenarios:catalogCodes.length}},null,2));
process.exitCode=errors.length===0?0:1;
