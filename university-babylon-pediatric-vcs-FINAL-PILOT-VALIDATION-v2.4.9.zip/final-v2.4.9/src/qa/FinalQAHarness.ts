import { InteractionRegistry } from "../scene/InteractionRegistry";
import { ScenarioCatalog } from "../scenarios/ScenarioCatalog";
import { OperationalScenarioPackages } from "../scenarios/ScenarioPackage";
import { getScenarioClinicalMap } from "../scenarios/ScenarioClinicalMap";
import { buildScenarioTraceability } from "../scenarios/ScenarioTraceability";

export interface FinalQAResult { ok: boolean; errors: string[]; warnings: string[]; }

export function runFinalQA(): FinalQAResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const registry = new Map(InteractionRegistry.map(x => [x.actionId, x]));

  if (ScenarioCatalog.length !== 11) errors.push(`SCENARIO_COUNT:${ScenarioCatalog.length}`);
  if (new Set(ScenarioCatalog.map(x => x.code)).size !== ScenarioCatalog.length) errors.push("DUPLICATE_SCENARIO_CODES");

  for (const entry of ScenarioCatalog) {
    const pkg = OperationalScenarioPackages.find(x => x.catalog.id === entry.id);
    const map = getScenarioClinicalMap(entry.id);
    if (!pkg) errors.push(`MISSING_PACKAGE:${entry.id}`);
    if (!map) errors.push(`MISSING_CLINICAL_MAP:${entry.id}`);
    if (pkg && pkg.sourceFacts.length === 0) errors.push(`NO_SOURCE_FACTS:${entry.id}`);
    if (map && map.criteria.length === 0) errors.push(`NO_CRITERIA:${entry.id}`);
    if (map) for (const criterion of map.criteria) {
      if (!registry.has(criterion.actionId)) errors.push(`UNMAPPED_ACTION:${entry.id}:${criterion.actionId}`);
    }
  }

  const trace = buildScenarioTraceability();
  if (trace.some(row => row.executableMedicationLogic)) errors.push("EXECUTABLE_MEDICATION_LOGIC_PRESENT");
  if (trace.some(row => row.pendingCriteria > row.criteria)) errors.push("INVALID_PENDING_COUNT");
  if (trace.some(row => row.sourceFacts < 1)) errors.push("TRACEABILITY_SOURCE_GAP");

  if (trace.some(row => row.pendingCriteria > 0)) warnings.push("CLINICAL_VALIDATION_REMAINS_REQUIRED");
  warnings.push("FULL_BROWSER_BUILD_REQUIRES_INSTALLABLE_DEPENDENCY_ENVIRONMENT");
  warnings.push("CLINICAL_AUDIO_REQUIRES_SME_VALIDATION");

  return { ok: errors.length === 0, errors, warnings };
}

