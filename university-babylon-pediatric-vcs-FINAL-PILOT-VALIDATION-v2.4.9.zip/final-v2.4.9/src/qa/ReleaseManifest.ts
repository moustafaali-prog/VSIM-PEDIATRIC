export interface ReleaseManifest {
  version: string;
  sourceOfTruth: string[];
  implemented: string[];
  pendingClinicalValidation: string[];
  buildVerification: "NOT_RUN" | "PASSED" | "FAILED";
}

export const ReleaseManifest_v1_5_0: ReleaseManifest = {
  version: "2.4.4",
  sourceOfTruth: ["project files 01-07", "FILE-05 scenario-specific facts"],
  implemented: [
    "11 operational scenario packages",
    "shared safety-gated action vocabulary",
    "scenario-specific baseline state transcription",
    "source-fact traceability per scenario",
    "timed curveballs only where explicit timing exists in FILE-05",
    "non-executable medication boundary",
    "scenario registry and default runtime integration",
  ],
  pendingClinicalValidation: [
    "SME validation of all scenario facts and clinical rules",
    "validated medication/order-set execution",
    "full scenario-specific scoring rubrics",
    "validated auscultation/audio library",
    "production 3D asset QA",
  ],
  buildVerification: "NOT_RUN",
};
