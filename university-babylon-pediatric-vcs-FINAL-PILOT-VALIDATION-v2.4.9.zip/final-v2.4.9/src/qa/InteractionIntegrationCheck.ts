import { InteractionRegistry } from "../scene/InteractionRegistry";

export function validateInteractionRegistry(): { ok: boolean; errors: string[] } {
  const errors: string[] = [];
  const seen = new Set<string>();
  for (const item of InteractionRegistry) {
    if (seen.has(item.actionId)) errors.push(`Duplicate action mapping: ${item.actionId}`);
    seen.add(item.actionId);
    if (!item.target) errors.push(`Missing target for ${item.actionId}`);
    if (item.patientContact && !item.procedure && item.actionId !== "position_high_fowler") {
      errors.push(`Patient-contact action lacks procedure mapping: ${item.actionId}`);
    }
  }
  return { ok: errors.length === 0, errors };
}
