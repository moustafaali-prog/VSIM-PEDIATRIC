import * as THREE from "three";
import { DEFAULT_ROOM_SPEC } from "./RoomSpecification";

export interface RoomBuildResult {
  root: THREE.Group;
  patientRoot: THREE.Group;
  monitorRoot: THREE.Group;
  interactionObjects: Map<string, THREE.Object3D>;
}

function box(
  size: THREE.Vector3,
  position: THREE.Vector3,
  material: THREE.Material,
): THREE.Mesh {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(size.x, size.y, size.z), material);
  mesh.position.copy(position);
  return mesh;
}

export function buildProceduralRoom(): RoomBuildResult {
  const root = new THREE.Group();
  root.name = "hospital_room";

  const interactionObjects = new Map<string, THREE.Object3D>();

  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(DEFAULT_ROOM_SPEC.width, DEFAULT_ROOM_SPEC.depth),
    new THREE.MeshStandardMaterial({ roughness: 0.9 }),
  );
  floor.rotation.x = -Math.PI / 2;
  root.add(floor);

  const wallMaterial = new THREE.MeshStandardMaterial({ roughness: 0.85 });
  root.add(
    box(
      new THREE.Vector3(DEFAULT_ROOM_SPEC.width, DEFAULT_ROOM_SPEC.height, 0.12),
      new THREE.Vector3(0, DEFAULT_ROOM_SPEC.height / 2, -DEFAULT_ROOM_SPEC.depth / 2),
      wallMaterial,
    ),
  );

  const bed = new THREE.Group();
  bed.name = "clickable_bed";
  bed.add(
    box(
      new THREE.Vector3(2.2, 0.22, 1.0),
      new THREE.Vector3(0, 1.0, 0),
      new THREE.MeshStandardMaterial({ roughness: 0.7 }),
    ),
  );
  root.add(bed);
  interactionObjects.set("clickable_bed", bed);

  const patientRoot = new THREE.Group();
  patientRoot.name = "clickable_patient";
  patientRoot.position.set(0, 1.15, 0);
  root.add(patientRoot);
  interactionObjects.set("clickable_patient", patientRoot);

  const torso = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.34, 0.85, 8, 16),
    new THREE.MeshStandardMaterial({ roughness: 0.7 }),
  );
  torso.scale.set(1.0, 0.9, 0.62);
  torso.rotation.z = Math.PI / 2;
  patientRoot.add(torso);

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 16, 12),
    new THREE.MeshStandardMaterial({ roughness: 0.65 }),
  );
  head.position.set(0.7, 0.12, 0);
  head.name = "clickable_head";
  patientRoot.add(head);
  interactionObjects.set("clickable_head", head);

  const chest = new THREE.Group();
  chest.name = "clickable_chest";
  chest.position.set(0.2, 0.05, 0.18);
  patientRoot.add(chest);
  interactionObjects.set("clickable_chest", chest);

  const monitor = new THREE.Group();
  monitor.name = "clickable_monitor";
  monitor.position.set(2.0, 1.9, -0.5);
  root.add(monitor);
  interactionObjects.set("clickable_monitor", monitor);

  const oxygen = new THREE.Group();
  oxygen.name = "clickable_oxygen";
  oxygen.position.set(1.8, 0.8, 0.6);
  root.add(oxygen);
  interactionObjects.set("clickable_oxygen", oxygen);

  const handwash = new THREE.Group();
  handwash.name = "clickable_handwash";
  handwash.position.set(-3.0, 1.0, -2.7);
  root.add(handwash);
  interactionObjects.set("clickable_handwash", handwash);

  return { root, patientRoot, monitorRoot: monitor, interactionObjects };
}
