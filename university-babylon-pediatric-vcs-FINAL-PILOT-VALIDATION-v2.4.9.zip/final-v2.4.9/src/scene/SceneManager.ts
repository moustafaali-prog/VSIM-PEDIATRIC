import * as THREE from "three";
import type { ClinicalState } from "../clinical/ClinicalState";
import { buildDetailedPatient, buildDetailedNurse, buildClinicalEquipment } from "./HighFidelityProceduralModels";
import { WebAudioMonitor } from "../audio/WebAudioMonitor";
import { ClinicalAudioController } from "../audio/ClinicalAudioController";
import { ClinicalSceneBridge } from "./ClinicalSceneBridge";
import { EquipmentInteraction, type InteractionTarget } from "./EquipmentInteraction";
import { ProcedureVisualController } from "./ProcedureVisualController";
import type { ProcedureVisualState } from "./ProcedureVisualState";
import type { ClinicalActionId } from "../clinical/ActionTypes";
import { getRenderProfile } from "../platform/RenderQuality";
import { detectDeviceProfile } from "../platform/DeviceProfile";

export class SceneManager {
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(45,1,.05,100);
  readonly renderer: THREE.WebGLRenderer;
  private readonly patient: THREE.Group;
  private readonly nurse: THREE.Group;
  private readonly monitorScreen: THREE.Mesh;
  private time=0;
  private bedHead=0;
  private readonly audio=new WebAudioMonitor();
  private readonly clinicalAudio=new ClinicalAudioController();
  private readonly bridge: ClinicalSceneBridge;
  private readonly raycaster=new THREE.Raycaster();
  private readonly pointer=new THREE.Vector2();
  private readonly interaction: EquipmentInteraction;
  private readonly procedureVisual: ProcedureVisualController;
  private procedureVisualState: ProcedureVisualState = { id: null, phase: "idle", progress: 0, target: null };
  private actionHandler: ((actionId: ClinicalActionId, target: InteractionTarget) => void) | undefined;

  constructor(private readonly host:HTMLElement) {
    this.scene.background=new THREE.Color(0xdbe3ea);
    this.renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:"high-performance"});
    const device=detectDeviceProfile();
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,device.maxDpr,getRenderProfile(device.recommendedQuality.toLowerCase() as "low"|"medium"|"high").pixelRatioCap));
    this.renderer.outputColorSpace=THREE.SRGBColorSpace;
    host.appendChild(this.renderer.domElement);
    this.scene.add(new THREE.HemisphereLight(0xffffff,0x53606c,2.0));
    const key=new THREE.DirectionalLight(0xffffff,2.3);key.position.set(3,6,4);this.scene.add(key);
    this.buildRoom();
    this.patient=buildDetailedPatient();this.patient.position.set(0,0.98,0);this.scene.add(this.patient);
    this.bridge=new ClinicalSceneBridge(this.scene,this.patient,this.clinicalAudio);
    this.nurse=buildDetailedNurse();
    this.nurse.position.set(2.0,0,1.2);this.scene.add(this.nurse);
    this.procedureVisual=new ProcedureVisualController(this.nurse);
    const equipment=buildClinicalEquipment();this.scene.add(equipment);
    this.interaction = new EquipmentInteraction(this.camera, this.scene);
    const screen=equipment.getObjectByProperty("type","Mesh");
    this.monitorScreen=(equipment.getObjectByName("clickable_monitor")?.children.find((x: THREE.Object3D)=>x instanceof THREE.Mesh && (x as THREE.Mesh).geometry instanceof THREE.BoxGeometry && (x as THREE.Mesh).position.z>.1) as THREE.Mesh) ?? screen as THREE.Mesh;
    this.camera.position.set(4,2.8,5);this.camera.lookAt(0,1.2,0);
    this.resize(host.clientWidth,host.clientHeight);
    this.renderer.domElement.addEventListener("pointerdown",(event: PointerEvent)=>{
      this.audio.enable();
      const target=this.interaction.pick(event.clientX,event.clientY,this.renderer.domElement);
      if(target){
        this.actionHandler?.(target.actionId,target);
      }
    });
  }
  private buildRoom(){
    const m=(c:number,r=.75,me=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:me});
    const add=(geo:THREE.BufferGeometry,c:number,pos:THREE.Vector3,rot?:THREE.Euler)=>{const x=new THREE.Mesh(geo,m(c));x.position.copy(pos);if(rot)x.rotation.copy(rot);this.scene.add(x);};
    add(new THREE.BoxGeometry(9,.08,9),0xe3e5e8,new THREE.Vector3(0,-.04,0));
    add(new THREE.BoxGeometry(9,4,.08),0xf3f4f5,new THREE.Vector3(0,2,-4));
    add(new THREE.BoxGeometry(.08,4,9),0xf0f1f2,new THREE.Vector3(-4.5,2,0));
    for(const x of [-2,0,2]) add(new THREE.BoxGeometry(1.3,.05,.35),0xffffff,new THREE.Vector3(x,3.9,-.5));
    add(new THREE.BoxGeometry(2.5,.25,4),0xb7bec6,new THREE.Vector3(0,.75,0));
    add(new THREE.BoxGeometry(2.25,.22,3.7),0xffffff,new THREE.Vector3(0,.98,0));
  }
  updateFromClinicalState(state:Readonly<ClinicalState>,delta:number){
    this.time+=delta;
    this.bridge.update(state);
    this.procedureVisual.update(this.procedureVisualState, delta);
    const bedTarget=state.position==="high_fowler"?.55:state.position==="semi_fowler"?.28:0;
    this.bedHead += (bedTarget-this.bedHead)*Math.min(1,delta*6);
    this.patient.rotation.x=this.bedHead;
    if(this.monitorScreen?.material instanceof THREE.MeshStandardMaterial){
      const pulse=Math.sin(this.time*8)*.08+.92;
      this.monitorScreen.material.emissive=new THREE.Color(0x0a8f78);
      this.monitorScreen.material.emissiveIntensity=pulse;
    }
    this.audio.beep(this.time,state.cardiovascular.heartRate);
  }
  onClinicalAction(handler: (actionId: ClinicalActionId, target: InteractionTarget) => void): void { this.actionHandler=handler; }
  setProcedureVisualState(state: ProcedureVisualState): void { this.procedureVisualState = { ...state }; }
  resize(w:number,h:number){this.camera.aspect=w/Math.max(h,1);this.camera.updateProjectionMatrix();this.renderer.setSize(w,h,false);}
  render(){this.renderer.render(this.scene,this.camera);}
  dispose(){this.bridge.dispose();this.renderer.dispose();}
}
