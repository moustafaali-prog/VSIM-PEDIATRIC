import * as THREE from "three";
import type { ClinicalState } from "../clinical/ClinicalState";
import { PatientVisualController } from "./PatientVisualController";
import { deriveClinicalPresentation } from "./ClinicalStatePresentation";
import { ClinicalAudioController } from "../audio/ClinicalAudioController";

export class ClinicalSceneBridge {
  private readonly patientVisual: PatientVisualController;

  constructor(
    private readonly scene: THREE.Scene,
    patientRoot: THREE.Object3D,
    private readonly audio?: ClinicalAudioController,
  ) {
    this.patientVisual = new PatientVisualController(patientRoot);
  }

  update(state: ClinicalState): void {
    const presentation = deriveClinicalPresentation(state);
    this.patientVisual.update(state, presentation);
    this.audio?.setClinicalSounds(presentation.sounds);
  }

  dispose(): void {
    this.scene.traverse((object: THREE.Object3D) => {
      const mesh = object as THREE.Mesh;
      const geometry = mesh.geometry;
      const material = (mesh as any).material;
      if (geometry?.dispose) geometry.dispose();
      const materials = Array.isArray(material) ? material : [material];
      for (const m of materials) {
        if (!m) continue;
        if (m.map?.dispose) m.map.dispose();
        if (m.normalMap?.dispose) m.normalMap.dispose();
        if (m.roughnessMap?.dispose) m.roughnessMap.dispose();
        if (m.dispose) m.dispose();
      }
    });
  }
}
