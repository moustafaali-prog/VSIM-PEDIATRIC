import type { ClinicalActionId } from "../clinical/ActionTypes";

export interface InteractionDefinition {
  actionId: ClinicalActionId;
  target: string;
  procedure?: string;
  patientContact: boolean;
}

export const InteractionRegistry: readonly InteractionDefinition[] = [
  { actionId: "review_ehr", target: "ui_ehr", patientContact: false },
  { actionId: "hand_hygiene", target: "clickable_handwash", procedure: "HAND_HYGIENE", patientContact: false },
  { actionId: "identify_patient", target: "clickable_wristband", patientContact: false },
  { actionId: "check_allergies", target: "ui_allergies", patientContact: false },
  { actionId: "initial_vitals", target: "clickable_monitor", patientContact: false },
  { actionId: "pat_assessment", target: "clickable_patient", procedure: "PAT_ASSESSMENT", patientContact: true },
  { actionId: "auscultate_lungs", target: "clickable_chest", procedure: "AUSCULTATION", patientContact: true },
  { actionId: "auscultate_heart", target: "clickable_heart", procedure: "AUSCULTATION", patientContact: true },
  { actionId: "pupil_exam", target: "clickable_head", procedure: "PERRLA", patientContact: true },
  { actionId: "capillary_refill", target: "clickable_wrist", procedure: "CAPILLARY_REFILL", patientContact: true },
  { actionId: "position_high_fowler", target: "clickable_bed", patientContact: true },
  { actionId: "position_left_lateral", target: "clickable_bed", patientContact: true },
  { actionId: "position_knee_chest", target: "clickable_bed", patientContact: true },
  { actionId: "apply_oxygen", target: "clickable_oxygen", procedure: "OXYGEN_SETUP", patientContact: true },
  { actionId: "start_nebulizer", target: "clickable_nebulizer", procedure: "NEBULIZER_SETUP", patientContact: true },
  { actionId: "blood_glucose_check", target: "clickable_glucose", procedure: "BLOOD_GLUCOSE", patientContact: true },
  { actionId: "obtain_blood_cultures", target: "clickable_arm", procedure: "BLOOD_CULTURE", patientContact: true },
  { actionId: "review_labs", target: "ui_labs", patientContact: false },
  { actionId: "maintain_npo", target: "ui_orders", patientContact: false },
  { actionId: "oral_suction", target: "clickable_suction", procedure: "ORAL_SUCTION", patientContact: true },
  { actionId: "call_emergency_team", target: "ui_emergency", patientContact: false },
  { actionId: "reassess_vitals", target: "clickable_monitor", patientContact: false },
  { actionId: "reassess_neuro", target: "clickable_head", procedure: "PERRLA", patientContact: true },
  { actionId: "document", target: "ui_documentation", patientContact: false },
  { actionId: "sbar_handover", target: "ui_sbar", patientContact: false },
];

export function getInteraction(actionId: ClinicalActionId): InteractionDefinition | undefined {
  return InteractionRegistry.find(x => x.actionId === actionId);
}
