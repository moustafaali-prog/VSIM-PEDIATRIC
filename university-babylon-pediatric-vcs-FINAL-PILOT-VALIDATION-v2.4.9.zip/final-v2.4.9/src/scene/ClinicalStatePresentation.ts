import type { ClinicalState } from "../clinical/ClinicalState";
import type { ClinicalSound } from "../audio/ClinicalAudioController";

export interface ClinicalPresentation {
  respiratoryMotionHz: number;
  respiratoryAmplitude: number;
  perfusion: "normal" | "pale" | "cyanotic" | "unknown";
  alarm: boolean;
  sounds: ClinicalSound[];
}

/** Pure projection: clinical state -> presentation cues. It never changes physiology. */
export function deriveClinicalPresentation(state: ClinicalState): ClinicalPresentation {
  const rr = state.respiratory.rate;
  const respiratoryMotionHz = rr != null && rr > 0 ? rr / 60 : 0;
  const respiratoryAmplitude = state.respiratory.effort === "severe"
    ? 0.045
    : state.respiratory.effort === "increased"
      ? 0.022
      : 0.008;

  const spo2 = state.respiratory.oxygenSaturation;
  const perfusion = spo2 == null
    ? "unknown"
    : spo2 >= 95 ? "normal" : spo2 >= 88 ? "pale" : "cyanotic";

  const sounds: ClinicalSound[] = ["ambient"];
  if (state.respiratory.effort === "severe") sounds.push("monitor_alarm");
  if (state.flags["wheeze"]) sounds.push("wheeze");
  if (state.flags["diminished_breath"]) sounds.push("diminished_breath");
  if (state.flags["silent_chest"]) sounds.push("silent_chest");
  if (state.flags["crying"] || state.flags["distress"]) sounds.push("crying");

  return { respiratoryMotionHz, respiratoryAmplitude, perfusion, alarm: state.respiratory.effort === "severe", sounds };
}
