import { ClinicalState } from "../clinical/ClinicalState";

export interface ClinicalVisualState {
  oxygenSaturation: number | null;
  respiratoryEffort: ClinicalState["respiratory"]["effort"];
  heartRate: number | null;
  respiratoryRate: number | null;
  pain: number | null;
  hydration: ClinicalState["hydration"]["status"];
  perfusion: "normal" | "pale" | "cyanotic" | "unknown";
}

export function deriveClinicalVisualState(
  state: ClinicalState,
): ClinicalVisualState {
  const spo2 = state.respiratory.oxygenSaturation;

  let perfusion: ClinicalVisualState["perfusion"] = "unknown";
  if (spo2 !== null) {
    if (spo2 >= 95) perfusion = "normal";
    else if (spo2 >= 88) perfusion = "pale";
    else perfusion = "cyanotic";
  }

  return {
    oxygenSaturation: spo2,
    respiratoryEffort: state.respiratory.effort,
    heartRate: state.cardiovascular.heartRate,
    respiratoryRate: state.respiratory.rate,
    pain: state.pain.score,
    hydration: state.hydration.status,
    perfusion,
  };
}
