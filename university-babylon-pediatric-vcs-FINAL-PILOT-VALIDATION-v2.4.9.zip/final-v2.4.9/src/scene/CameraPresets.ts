import * as THREE from "three";

export type CameraPreset =
  | "room"
  | "patient_closeup"
  | "telemetry"
  | "bedside";

export interface CameraPose {
  position: THREE.Vector3;
  lookAt: THREE.Vector3;
}

export const CAMERA_PRESETS: Record<CameraPreset, CameraPose> = {
  room: {
    position: new THREE.Vector3(5.8, 4.2, 6.2),
    lookAt: new THREE.Vector3(0, 1.1, 0),
  },
  patient_closeup: {
    position: new THREE.Vector3(1.6, 1.9, 3.1),
    lookAt: new THREE.Vector3(0, 1.2, 0),
  },
  telemetry: {
    position: new THREE.Vector3(3.1, 2.6, 2.2),
    lookAt: new THREE.Vector3(1.8, 1.8, 0),
  },
  bedside: {
    position: new THREE.Vector3(2.8, 1.7, 3.8),
    lookAt: new THREE.Vector3(0, 1.0, 0),
  },
};
