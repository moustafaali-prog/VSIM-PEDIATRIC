import * as THREE from "three";

function mat(color: number, roughness = 0.65, metalness = 0): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness });
}
function addCapsule(parent: THREE.Object3D, name: string, radius: number, length: number, material: THREE.Material, pos: THREE.Vector3): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 8, 16), material);
  m.name = name; m.position.copy(pos); parent.add(m); return m;
}

export function buildDetailedPatient(): THREE.Group {
  const root = new THREE.Group(); root.name = "clickable_patient";
  const skin = mat(0xfcd5b5, 0.62); skin.userData.isSkin = true;
  const hair = mat(0x3b2b24, 0.9);
  const gown = mat(0xe7edf2, 0.88);
  const dark = mat(0x20252a, 0.35);

  const pelvis = new THREE.Mesh(new THREE.SphereGeometry(0.38, 24, 16), gown); pelvis.scale.set(1.1, 0.55, 0.75); pelvis.position.set(0, 0.62, 0); root.add(pelvis);
  const torso = addCapsule(root, "skin_torso", 0.42, 0.82, gown, new THREE.Vector3(0, 1.18, 0)); torso.scale.set(1.1, 1, 0.78);
  const neck = addCapsule(root, "skin_neck", 0.13, 0.18, skin, new THREE.Vector3(0, 1.72, 0));
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.34, 28, 20), skin); head.name="clickable_head"; head.position.set(0,2.05,0); root.add(head);
  const hairCap = new THREE.Mesh(new THREE.SphereGeometry(0.345, 24, 14, 0, Math.PI*2, 0, Math.PI*0.55), hair); hairCap.position.copy(head.position); hairCap.position.y += 0.04; root.add(hairCap);
  for (const x of [-0.13,0.13]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.032, 12, 8), dark); eye.position.set(x,2.06,0.315); eye.name="eye"; root.add(eye);
  }
  const mouth = new THREE.Mesh(new THREE.TorusGeometry(0.055,0.008,6,20,Math.PI), dark); mouth.rotation.x=Math.PI/2; mouth.position.set(0,1.93,0.33); root.add(mouth);
  for (const side of [-1,1]) {
    const arm = addCapsule(root, `clickable_arm_${side}`, 0.11, 0.68, gown, new THREE.Vector3(side*0.54,1.17,0)); arm.rotation.z=side*0.12;
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.12,16,10), skin); hand.name=`clickable_wrist_${side}`; hand.position.set(side*0.60,0.73,0); root.add(hand);
    const thigh = addCapsule(root, `leg_${side}`, 0.16, 0.75, gown, new THREE.Vector3(side*0.22,0.22,0)); thigh.rotation.x=0.02;
    const foot = new THREE.Mesh(new THREE.BoxGeometry(0.24,0.12,0.48), dark); foot.position.set(side*0.22,-0.25,0.16); root.add(foot);
  }
  const chest = new THREE.Group(); chest.name="clickable_chest"; chest.position.set(0,1.30,0.37); root.add(chest);
  const chestMarker = new THREE.Mesh(new THREE.SphereGeometry(0.22,16,10), new THREE.MeshBasicMaterial({transparent:true,opacity:0})); chestMarker.name="clickable_chest"; chest.add(chestMarker);
  const heartMarker = new THREE.Mesh(new THREE.SphereGeometry(0.12,12,8), new THREE.MeshBasicMaterial({transparent:true,opacity:0})); heartMarker.name="clickable_heart"; heartMarker.position.set(0.10,0.02,0.02); chest.add(heartMarker);
  const glucoseMarker = new THREE.Mesh(new THREE.SphereGeometry(0.08,12,8), new THREE.MeshBasicMaterial({transparent:true,opacity:0})); glucoseMarker.name="clickable_glucose"; glucoseMarker.position.set(0.60,0.73,0.04); root.add(glucoseMarker);
  const wristband = new THREE.Mesh(new THREE.BoxGeometry(0.24,0.06,0.08), new THREE.MeshStandardMaterial({color:0xffffff,roughness:0.5})); wristband.name="clickable_wristband"; wristband.position.set(0.64,0.76,0); root.add(wristband);
  void neck;
  return root;
}

export function buildDetailedNurse(): THREE.Group {
  const root = new THREE.Group(); root.name="nurse_high_fidelity";
  const skin=mat(0xd9a47f,0.62,0.0); const scrubs=mat(0xb7c9d8,0.82); const shoe=mat(0x20262b,0.55); const hair=mat(0x2a211c,0.92);
  const body=addCapsule(root,"nurse_torso",0.34,0.82,scrubs,new THREE.Vector3(0,1.18,0)); body.scale.set(1.05,1,0.72);
  const head=new THREE.Mesh(new THREE.SphereGeometry(0.29,24,18),skin);head.position.y=1.98;root.add(head);
  const hairCap=new THREE.Mesh(new THREE.SphereGeometry(0.30,20,12,0,Math.PI*2,0,Math.PI*.58),hair);hairCap.position.set(0,2.02,0);root.add(hairCap);
  for(const side of [-1,1]){
    addCapsule(root,`nurse_upper_arm_${side}`,0.085,0.55,scrubs,new THREE.Vector3(side*.42,1.28,0));
    addCapsule(root,`nurse_forearm_${side}`,0.075,0.50,skin,new THREE.Vector3(side*.48,.90,.03));
    const hand=new THREE.Mesh(new THREE.SphereGeometry(.09,12,8),skin);hand.name=`nurse_hand_${side}`;hand.position.set(side*.50,.60,.04);root.add(hand);
    addCapsule(root,`nurse_leg_${side}`,0.10,.95,scrubs,new THREE.Vector3(side*.16,.42,0));
    const s=new THREE.Mesh(new THREE.BoxGeometry(.22,.12,.40),shoe);s.position.set(side*.16,-.15,.10);root.add(s);
  }
  return root;
}

export function buildClinicalEquipment(): THREE.Group {
  const root=new THREE.Group();root.name="clinical_equipment_high_fidelity";
  const metal=mat(0xaeb7bf,.3,.65), dark=mat(0x20282f,.32,.25), white=mat(0xf1f3f4,.7), glass=new THREE.MeshPhysicalMaterial({color:0xcfe8f4,roughness:.15,metalness:0,transmission:.25,transparent:true,opacity:.78});
  const monitor=new THREE.Group();monitor.name="clickable_monitor";monitor.position.set(-2.1,1.75,-1.25);root.add(monitor);
  const body=new THREE.Mesh(new THREE.BoxGeometry(1.1,.9,.25),dark);monitor.add(body);
  const screen=new THREE.Mesh(new THREE.BoxGeometry(.9,.62,.025),new THREE.MeshBasicMaterial({color:0x061015}));screen.position.z=.14;monitor.add(screen);
  const stand=new THREE.Mesh(new THREE.CylinderGeometry(.035,.035,.75,10),metal);stand.position.set(0,-.78,0);monitor.add(stand);
  const base=new THREE.Mesh(new THREE.BoxGeometry(.55,.06,.32),metal);base.position.set(0,-1.15,0);monitor.add(base);
  const oxygen=new THREE.Group();oxygen.name="clickable_oxygen";oxygen.position.set(-2.7,.7,.9);root.add(oxygen);
  const tank=new THREE.Mesh(new THREE.CylinderGeometry(.18,.18,1.35,20),metal);oxygen.add(tank);
  const iv=new THREE.Group();iv.name="clickable_iv";iv.position.set(1.65,0, -.45);root.add(iv);
  const pole=new THREE.Mesh(new THREE.CylinderGeometry(.025,.025,3,12),metal);pole.position.y=1.5;iv.add(pole);
  const bag=new THREE.Mesh(new THREE.BoxGeometry(.42,.62,.12),glass);bag.position.y=2.75;iv.add(bag);
  const bed=new THREE.Group();bed.name="clickable_bed";root.add(bed);
  const railMat=mat(0x8d969e,.38,.4);
  for(const side of [-1,1]){const rail=new THREE.Mesh(new THREE.BoxGeometry(.06,.45,3.3),railMat);rail.name="clickable_bed_rail";rail.position.set(side*1.15,.35,0);bed.add(rail);}
  const sink=new THREE.Mesh(new THREE.BoxGeometry(1.4,.65,.55),white);sink.name="clickable_handwash";sink.position.set(-3.1,.75,-2.5);root.add(sink);
  const nebulizer=new THREE.Group();nebulizer.name="clickable_nebulizer";nebulizer.position.set(.45,1.0,.42);root.add(nebulizer);
  nebulizer.add(new THREE.Mesh(new THREE.CylinderGeometry(.10,.12,.20,16),white));
  const suction=new THREE.Group();suction.name="clickable_suction";suction.position.set(.18,1.05,.65);root.add(suction);
  suction.add(new THREE.Mesh(new THREE.CylinderGeometry(.025,.04,.55,12),dark));
  return root;
}
