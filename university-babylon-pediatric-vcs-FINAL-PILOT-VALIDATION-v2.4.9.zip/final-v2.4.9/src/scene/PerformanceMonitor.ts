export interface PerformanceSnapshot {
  fps: number;
  frameTimeMs: number;
  devicePixelRatio: number;
}

export class PerformanceMonitor {
  private frames = 0;
  private elapsed = 0;
  private fps = 0;

  update(deltaSeconds: number): PerformanceSnapshot {
    this.frames++;
    this.elapsed += deltaSeconds;

    if (this.elapsed >= 0.5) {
      this.fps = this.frames / this.elapsed;
      this.frames = 0;
      this.elapsed = 0;
    }

    return {
      fps: this.fps,
      frameTimeMs: this.fps > 0 ? 1000 / this.fps : 0,
      devicePixelRatio: Math.min(window.devicePixelRatio || 1, 2),
    };
  }
}
