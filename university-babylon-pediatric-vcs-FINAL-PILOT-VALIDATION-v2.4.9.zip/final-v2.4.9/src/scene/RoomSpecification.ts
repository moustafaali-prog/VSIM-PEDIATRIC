export interface RoomSpecification {
  width: number;
  depth: number;
  height: number;
  targetDrawCalls: number;
  targetVramMB: number;
  targetFps: number;
}

export const DEFAULT_ROOM_SPEC: RoomSpecification = {
  width: 8,
  depth: 7,
  height: 3.2,
  targetDrawCalls: 45,
  targetVramMB: 180,
  targetFps: 60,
};
