import type { ProcedureId, ProcedurePhase } from "../procedures/ProcedureStateMachine";

export interface ProcedureVisualState {
  id: ProcedureId | null;
  phase: ProcedurePhase;
  progress: number;
  target: string | null;
}

export const IDLE_PROCEDURE_VISUAL: ProcedureVisualState = {
  id: null,
  phase: "idle",
  progress: 0,
  target: null,
};
