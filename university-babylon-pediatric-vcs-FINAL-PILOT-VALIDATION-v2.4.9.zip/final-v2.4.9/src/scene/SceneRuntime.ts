import * as THREE from "three";
import { ClinicalState } from "../clinical/ClinicalState";
import { ClinicalSceneBridge } from "./ClinicalSceneBridge";
import { PerformanceMonitor } from "./PerformanceMonitor";
import { buildProceduralRoom } from "./ProceduralRoomBuilder";
import { RaycastInteraction } from "../interaction/RaycastInteraction";
import { CLINICAL_INTERACTION_MAP } from "../interaction/ClinicalInteractionMap";
import { TouchController } from "../interaction/TouchController";
import { ClinicalAudioController } from "../audio/ClinicalAudioController";
import { deriveClinicalSounds } from "../clinical/ClinicalAudioState";

export interface SceneRuntimeOptions {
  onClinicalAction: (actionId: any) => void;
}

export class SceneRuntime {
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(50, 1, 0.05, 100);
  readonly renderer: THREE.WebGLRenderer;
  readonly raycast = new RaycastInteraction();
  readonly performance = new PerformanceMonitor();
  readonly audio = new ClinicalAudioController();

  private readonly bridge: ClinicalSceneBridge;
  private readonly clock = new THREE.Clock();

  constructor(
    private readonly canvas: HTMLCanvasElement,
    options: SceneRuntimeOptions,
  ) {
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: "high-performance",
    });

    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setAnimationLoop(() => this.frame());

    const room = buildProceduralRoom();
    this.scene.add(room.root);

    for (const [id, object] of room.interactionObjects) {
      this.raycast.register({ id, object, enabled: true });
    }

    this.bridge = new ClinicalSceneBridge(this.scene, room.patientRoot);

    for (const [targetName, actionId] of Object.entries(CLINICAL_INTERACTION_MAP)) {
      if (room.interactionObjects.has(targetName)) {
        // The action mapping is resolved by the application controller.
        // Keep target registration in one place.
        void actionId;
      }
    }

    new TouchController(
      canvas,
      this.camera,
      this.raycast,
      (targetId) => {
        const actionId = CLINICAL_INTERACTION_MAP[targetId];
        if (actionId) options.onClinicalAction(actionId);
      },
    ).attach();

    this.resize();
    window.addEventListener("resize", () => this.resize());
  }

  updateClinicalState(state: ClinicalState): void {
    this.bridge.update(state);
    this.audio.setClinicalSounds(deriveClinicalSounds(state));
  }

  private frame(): void {
    const delta = this.clock.getDelta();
    this.performance.update(delta);
    this.renderer.render(this.scene, this.camera);
  }

  private resize(): void {
    const width = this.canvas.clientWidth || window.innerWidth;
    const height = this.canvas.clientHeight || window.innerHeight;
    this.camera.aspect = width / Math.max(height, 1);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
  }

  dispose(): void {
    this.renderer.setAnimationLoop(null);
    this.bridge.dispose();
    this.renderer.dispose();
  }
}
