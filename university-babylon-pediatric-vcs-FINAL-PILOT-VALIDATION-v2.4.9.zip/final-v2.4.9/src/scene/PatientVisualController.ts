import * as THREE from "three";
import type { ClinicalState } from "../clinical/ClinicalState";
import type { ClinicalPresentation } from "./ClinicalStatePresentation";

export class PatientVisualController {
  private readonly targetColor = new THREE.Color();
  private readonly basePosition = new THREE.Vector3();

  constructor(private readonly patientRoot: THREE.Object3D) {
    this.basePosition.copy(patientRoot.position);
  }

  update(state: ClinicalState, presentation?: ClinicalPresentation): void {
    const p = presentation;
    const rr = p?.respiratoryMotionHz ?? ((state.respiratory.rate ?? 0) / 60);
    const amplitude = p?.respiratoryAmplitude ?? 0.008;
    const phase = state.timeSeconds * Math.PI * 2 * rr;
    this.patientRoot.position.y = this.basePosition.y + Math.sin(phase) * amplitude;
    this.updatePerfusion(p?.perfusion ?? this.perfusionFromState(state));
    this.updateDistress(state);
  }

  private perfusionFromState(state: ClinicalState): "normal" | "pale" | "cyanotic" | "unknown" {
    const spo2 = state.respiratory.oxygenSaturation;
    if (spo2 == null) return "unknown";
    return spo2 >= 95 ? "normal" : spo2 >= 88 ? "pale" : "cyanotic";
  }

  private updateDistress(state: ClinicalState): void {
    const distressed = state.respiratory.effort === "severe" || !!state.flags["distress"];
    this.patientRoot.traverse((object: THREE.Object3D) => {
      const mesh = object as THREE.Mesh;
      if (mesh.name !== "mouth" || !(mesh.material as any)?.color) return;
      const material = mesh.material as THREE.MeshStandardMaterial;
      material.opacity = distressed ? 0.95 : 1;
    });
  }

  private updatePerfusion(perfusion: "normal" | "pale" | "cyanotic" | "unknown"): void {
    const color =
      perfusion === "cyanotic" ? 0x7389a6 :
      perfusion === "pale" ? 0xf1e5d8 :
      perfusion === "normal" ? 0xfcd5b5 :
      0xd9b3a0;
    this.targetColor.setHex(color);
    this.patientRoot.traverse((object: THREE.Object3D) => {
      const mesh = object as THREE.Mesh;
      const material = (mesh as any).material;
      if (!material) return;
      const materials = Array.isArray(material) ? material : [material];
      for (const m of materials) {
        if (m.color?.isColor) m.color.lerp(this.targetColor, 0.12);
      }
    });
  }
}
