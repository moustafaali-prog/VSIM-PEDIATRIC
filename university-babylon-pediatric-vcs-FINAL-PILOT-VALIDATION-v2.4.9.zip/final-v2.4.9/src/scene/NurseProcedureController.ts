import * as THREE from "three";
import { solveTwoBoneIK } from "./TwoBoneIK";
import { ProcedureStateMachine, type ProcedureId } from "../procedures/ProcedureStateMachine";

const PROCEDURE_TARGETS: Record<ProcedureId, THREE.Vector3> = {
  HAND_HYGIENE: new THREE.Vector3(-3.1, 1.15, -2.5),
  AUSCULTATION: new THREE.Vector3(0.52, 1.45, 0.36),
  OXYGEN_SETUP: new THREE.Vector3(-2.7, 1.25, 0.9),
  NEBULIZER_SETUP: new THREE.Vector3(0.45, 1.25, 0.42),
  IV_SETUP: new THREE.Vector3(0.62, 0.78, 0.05),
  PERRLA: new THREE.Vector3(0.18, 2.06, 0.32),
  PAT_ASSESSMENT: new THREE.Vector3(0.0, 1.30, 0.37),
  CAPILLARY_REFILL: new THREE.Vector3(0.60, 0.73, 0.02),
  BLOOD_GLUCOSE: new THREE.Vector3(0.60, 0.73, 0.02),
  BLOOD_CULTURE: new THREE.Vector3(0.54, 1.17, 0.02),
  ORAL_SUCTION: new THREE.Vector3(0.18, 1.55, 0.32),
};

export class NurseProcedureController {
  readonly procedure = new ProcedureStateMachine();
  private readonly shoulder = new THREE.Vector3();
  private readonly pole = new THREE.Vector3(0, 1, 0);
  private readonly target = new THREE.Vector3();
  constructor(private readonly nurse: THREE.Object3D) {}

  begin(id: ProcedureId): void { this.procedure.begin(id); }

  update(delta: number): void {
    this.procedure.update(delta);
    const state = this.procedure.snapshot();
    if (state.phase === "idle" || state.phase === "cancelled") return;
    const side = state.id === "IV_SETUP" || state.id === "PERRLA" ? 1 : 1;
    const hand = this.nurse.getObjectByName(`nurse_hand_${side}`);
    if (!hand) return;
    const shoulderObject = this.nurse.getObjectByName(`nurse_upper_arm_${side}`);
    if (!shoulderObject) return;
    shoulderObject.getWorldPosition(this.shoulder);
    this.target.copy(PROCEDURE_TARGETS[state.id]);
    const localTarget = this.nurse.worldToLocal(this.target.clone());
    const result = solveTwoBoneIK(this.nurse.worldToLocal(this.shoulder.clone()), localTarget, this.pole, 0.55, 0.50);
    hand.position.copy(result.wrist);
  }
}
