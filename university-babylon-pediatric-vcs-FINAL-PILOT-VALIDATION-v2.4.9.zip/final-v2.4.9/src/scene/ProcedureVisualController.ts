import * as THREE from "three";
import type { ProcedureVisualState } from "./ProcedureVisualState";
import { solveTwoBoneIK } from "./TwoBoneIK";

const TARGET_POSITIONS: Record<string, THREE.Vector3> = {
  clickable_handwash: new THREE.Vector3(-3.1, 1.15, -2.5),
  clickable_chest: new THREE.Vector3(0.52, 1.45, 0.36),
  clickable_head: new THREE.Vector3(0.18, 2.06, 0.32),
  clickable_oxygen: new THREE.Vector3(-2.7, 1.25, 0.9),
  clickable_bed: new THREE.Vector3(0.0, 0.98, 0.0),
  clickable_patient: new THREE.Vector3(0.0, 1.30, 0.37),
  clickable_heart: new THREE.Vector3(0.10, 1.32, 0.39),
  clickable_glucose: new THREE.Vector3(0.60, 0.73, 0.04),
  clickable_wrist: new THREE.Vector3(0.60, 0.73, 0.02),
  clickable_arm: new THREE.Vector3(0.54, 1.17, 0.02),
  clickable_suction: new THREE.Vector3(0.18, 1.55, 0.32),
  clickable_nebulizer: new THREE.Vector3(0.45, 1.25, 0.42),
};

/** Presentation-only controller. It never mutates ClinicalState. */
export class ProcedureVisualController {
  private readonly target = new THREE.Vector3();
  private readonly handTarget = new THREE.Vector3();
  private active = false;

  constructor(private readonly nurse: THREE.Object3D) {}

  update(state: ProcedureVisualState, deltaSeconds: number): void {
    const hand = this.nurse.getObjectByName("nurse_hand_1");
    const shoulder = this.nurse.getObjectByName("nurse_upper_arm_1");
    if (!hand || !shoulder) return;
    if (!state.id || state.phase === "idle" || state.phase === "cancelled") {
      this.active = false;
      return;
    }
    const pos = state.target ? TARGET_POSITIONS[state.target] : undefined;
    if (!pos) return;
    shoulder.getWorldPosition(this.target);
    const targetWorld = pos.clone();
    const shoulderLocal = this.nurse.worldToLocal(this.target.clone());
    const targetLocal = this.nurse.worldToLocal(targetWorld);
    const phaseFactor = state.phase === "approach" ? 0.45 : state.phase === "perform" ? 0.95 : 1;
    const blendedTarget = shoulderLocal.clone().lerp(targetLocal, phaseFactor);
    const result = solveTwoBoneIK(shoulderLocal, blendedTarget, new THREE.Vector3(0, 1, 0), 0.55, 0.50);
    const alpha = Math.min(1, Math.max(0, deltaSeconds * 8));
    hand.position.lerp(result.wrist, alpha);
    this.active = true;
  }

  isActive(): boolean { return this.active; }
}
