import * as THREE from "three";
import type { ClinicalActionId } from "../clinical/ActionTypes";

export interface InteractionTarget {
  objectName: string;
  actionId: ClinicalActionId;
  label: string;
  procedure?: "HAND_HYGIENE" | "AUSCULTATION" | "OXYGEN_SETUP" | "NEBULIZER_SETUP" | "IV_SETUP" | "PERRLA" | "PAT_ASSESSMENT" | "CAPILLARY_REFILL" | "BLOOD_GLUCOSE" | "BLOOD_CULTURE" | "ORAL_SUCTION";
}

const TARGETS: readonly InteractionTarget[] = [
  { objectName: "clickable_handwash", actionId: "hand_hygiene", label: "Hand hygiene", procedure: "HAND_HYGIENE" },
  { objectName: "clickable_wristband", actionId: "identify_patient", label: "Patient identification" },
  { objectName: "clickable_chest", actionId: "auscultate_lungs", label: "Lung auscultation", procedure: "AUSCULTATION" },
  { objectName: "clickable_heart", actionId: "auscultate_heart", label: "Heart auscultation", procedure: "AUSCULTATION" },
  { objectName: "clickable_patient", actionId: "pat_assessment", label: "PAT assessment", procedure: "PAT_ASSESSMENT" },
  { objectName: "clickable_wrist", actionId: "capillary_refill", label: "Capillary refill", procedure: "CAPILLARY_REFILL" },
  { objectName: "clickable_glucose", actionId: "blood_glucose_check", label: "Blood glucose check", procedure: "BLOOD_GLUCOSE" },
  { objectName: "clickable_arm", actionId: "obtain_blood_cultures", label: "Blood cultures", procedure: "BLOOD_CULTURE" },
  { objectName: "clickable_head", actionId: "pupil_exam", label: "Pupil examination", procedure: "PERRLA" },
  { objectName: "clickable_oxygen", actionId: "apply_oxygen", label: "Oxygen setup", procedure: "OXYGEN_SETUP" },
  { objectName: "clickable_nebulizer", actionId: "start_nebulizer", label: "Nebulizer setup", procedure: "NEBULIZER_SETUP" },
  { objectName: "clickable_suction", actionId: "oral_suction", label: "Oral suction", procedure: "ORAL_SUCTION" },
  { objectName: "clickable_iv", actionId: "review_ehr", label: "IV equipment / orders" },
  { objectName: "clickable_monitor", actionId: "initial_vitals", label: "Monitor / vital signs" },
  { objectName: "clickable_bed", actionId: "position_high_fowler", label: "Bed positioning" },
];

export class EquipmentInteraction {
  private readonly raycaster = new THREE.Raycaster();
  private readonly pointer = new THREE.Vector2();
  constructor(private readonly camera: THREE.Camera, private readonly scene: THREE.Scene) {}

  pick(clientX: number, clientY: number, element: HTMLElement): InteractionTarget | undefined {
    const rect = element.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return undefined;
    this.pointer.set(((clientX - rect.left) / rect.width) * 2 - 1, -((clientY - rect.top) / rect.height) * 2 + 1);
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObjects(this.scene.children, true);
    for (const hit of hits) {
      const target = TARGETS.find(t => hit.object.name === t.objectName || hit.object.parent?.name === t.objectName || hit.object.name.startsWith(`${t.objectName}_`));
      if (target) return target;
    }
    return undefined;
  }
}
