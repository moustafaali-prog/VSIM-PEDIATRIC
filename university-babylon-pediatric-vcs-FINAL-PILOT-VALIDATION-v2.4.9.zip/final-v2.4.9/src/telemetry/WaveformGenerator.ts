export type WaveformKind = "ECG" | "PLETH" | "ABP" | "CAPNOGRAPHY";
export interface WaveformInput { heartRate?: number | null; respiratoryRate?: number | null; systolicBP?: number | null; diastolicBP?: number | null; }
export interface WaveformSample { t: number; value: number; }
const f = (v: number | null | undefined, d: number) => v != null && Number.isFinite(v) ? v : d;

export function generateWaveform(k: WaveformKind, i: WaveformInput, duration = 4, sampleRate = 250): WaveformSample[] {
  if (duration <= 0 || sampleRate <= 0) throw new Error("Invalid waveform parameters");
  const hr = Math.max(30, f(i.heartRate, 100));
  const rr = Math.max(4, f(i.respiratoryRate, 20));
  const sbp = f(i.systolicBP, 100);
  const dbp = f(i.diastolicBP, 60);
  const n = Math.ceil(duration * sampleRate);
  const out: WaveformSample[] = [];
  for (let j = 0; j < n; j++) {
    const t = j / sampleRate;
    const c = (t * hr / 60) % 1;
    const r = (t * rr / 60) % 1;
    let value = 0;
    if (k === "ECG") {
      value = 0.12 * Math.exp(-Math.pow((c - 0.18) / 0.035, 2))
        - 0.15 * Math.exp(-Math.pow((c - 0.30) / 0.012, 2))
        + Math.exp(-Math.pow((c - 0.32) / 0.01, 2))
        - 0.28 * Math.exp(-Math.pow((c - 0.35) / 0.014, 2))
        + 0.25 * Math.exp(-Math.pow((c - 0.55) / 0.07, 2));
    } else if (k === "PLETH") {
      const pulse = Math.exp(-Math.pow((c - 0.32) / 0.10, 2));
      const notch = 0.12 * Math.exp(-Math.pow((c - 0.55) / 0.035, 2));
      value = (0.15 + 0.85 * pulse - notch) * (0.95 + 0.05 * Math.sin(2 * Math.PI * r));
    } else if (k === "ABP") {
      const pulse = Math.pow(Math.max(0, Math.sin(Math.PI * c)), 1.7);
      value = dbp + (sbp - dbp) * pulse;
    } else {
      const rise = Math.min(1, c / 0.18);
      const plateau = c < 0.70 ? 1 : Math.max(0, 1 - (c - 0.70) / 0.18);
      value = 35 * Math.min(rise, plateau);
    }
    out.push({ t, value });
  }
  return out;
}
