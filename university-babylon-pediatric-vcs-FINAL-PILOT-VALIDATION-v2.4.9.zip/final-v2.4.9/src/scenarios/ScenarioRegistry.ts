import { OperationalScenarioPackages, getOperationalScenario } from "./ScenarioPackage";

export const SCENARIO_REGISTRY = OperationalScenarioPackages;
export { getOperationalScenario };
