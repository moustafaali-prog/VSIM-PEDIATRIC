import type { ClinicalState } from "../clinical/ClinicalState";
import type { ScenarioDefinition } from "./ScenarioSchema";

export class ScenarioEngine {
  private fired = new Set<string>();
  private scenario: ScenarioDefinition;

  constructor(scenario: ScenarioDefinition) { this.scenario = scenario; }

  setScenario(scenario: ScenarioDefinition): void {
    this.scenario = scenario;
    this.reset();
  }

  getScenario(): ScenarioDefinition { return this.scenario; }

  reset(): void { this.fired.clear(); }

  tick(state: ClinicalState): void {
    for (const event of this.scenario.events) {
      if (event.once && this.fired.has(event.id)) continue;
      if (event.trigger.type === "time" && state.timeSeconds >= event.trigger.atSeconds) {
        event.execute(state);
        if (event.once) this.fired.add(event.id);
      }
    }
  }

  handleAction(actionId: string, state: ClinicalState): void {
    const action = this.scenario.actions[actionId];
    if (action) action(state);
    for (const event of this.scenario.events) {
      if (event.once && this.fired.has(event.id)) continue;
      if (event.trigger.type === "action" && event.trigger.actionId === actionId) {
        event.execute(state);
        if (event.once) this.fired.add(event.id);
      }
    }
  }
}
