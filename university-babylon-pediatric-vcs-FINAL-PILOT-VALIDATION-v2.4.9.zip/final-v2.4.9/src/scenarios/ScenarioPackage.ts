import type { ClinicalState } from "../clinical/ClinicalState";
import type { ClinicalActionId } from "../clinical/ActionTypes";
import type { ScenarioEvent } from "../core/EventEngine";
import type { ScenarioDefinition, ValidatedParameter } from "./ScenarioSchema";
import { ScenarioCatalog, type ScenarioCatalogEntry } from "./ScenarioCatalog";

export interface ScenarioSourceFact {
  id: string;
  text: string;
  source: "FILE-05";
  status: "SOURCE_TRANSCRIPTION" | "PENDING_VALIDATION";
}

export interface OperationalScenarioPackage extends ScenarioDefinition {
  catalog: ScenarioCatalogEntry;
  sourceSupportedAllergies: readonly string[];
  sourceFacts: readonly ScenarioSourceFact[];
  executableMedicationLogic: false;
  clinicalValidationRequired: true;
}

const baseState = (v: Partial<ClinicalState> & Pick<ClinicalState, "respiratory" | "cardiovascular" | "pain" | "hydration" | "temperatureC">): ClinicalState => ({
  timeSeconds: 0,
  position: "supine",
  flags: {},
  audit: { handHygieneCompleted: false, patientIdentified: false, allergyCheckCompleted: false },
  ...v,
});

const param = <T>(value: T): ValidatedParameter<T> => ({
  value,
  source: "PROJECT_FILE",
  sourceId: "FILE-05",
  validationStatus: "SCENARIO_SPECIFIC",
});

function actionMap(): Record<string, (s: ClinicalState) => void> {
  return {
    review_ehr: s => { s.flags.ehrReviewed = true; },
    hand_hygiene: s => { s.audit.handHygieneCompleted = true; },
    identify_patient: s => { s.audit.patientIdentified = true; },
    check_allergies: s => { s.audit.allergyCheckCompleted = true; },
    initial_vitals: s => { s.flags.initialVitalsCompleted = true; },
    pat_assessment: s => { s.flags.patCompleted = true; },
    auscultate_lungs: s => { s.flags.lungAssessmentCompleted = true; },
    auscultate_heart: s => { s.flags.heartAssessmentCompleted = true; },
    pupil_exam: s => { s.flags.pupilExamCompleted = true; },
    capillary_refill: s => { s.flags.capillaryRefillCompleted = true; },
    position_high_fowler: s => { s.position = "high_fowler"; },
    position_left_lateral: s => { s.position = "lateral"; s.flags.leftLateralPosition = true; },
    position_knee_chest: s => { s.position = "other"; s.flags.kneeChestPosition = true; },
    apply_oxygen: s => { s.flags.oxygenApplied = true; },
    start_nebulizer: s => { s.flags.nebulizerStarted = true; },
    blood_glucose_check: s => { s.flags.bloodGlucoseChecked = true; },
    obtain_blood_cultures: s => { s.flags.bloodCulturesObtained = true; },
    review_labs: s => { s.flags.labsReviewed = true; },
    maintain_npo: s => { s.flags.npoMaintained = true; },
    oral_suction: s => { s.flags.oralSuctionPerformed = true; },
    call_emergency_team: s => { s.flags.emergencyTeamCalled = true; },
    reassess_vitals: s => { s.flags.reassessmentCompleted = true; },
    reassess_neuro: s => { s.flags.neuroReassessmentCompleted = true; },
    document: s => { s.flags.documentationCompleted = true; },
    sbar_handover: s => { s.flags.sbarCompleted = true; },
  };
}

const commonObjectives = ["Complete the mandatory safety gate.", "Recognize relevant clinical cues.", "Reassess after interventions.", "Communicate and document using SBAR."];

function makeScenario(entry: ScenarioCatalogEntry, state: ClinicalState, sourceFacts: ScenarioSourceFact[], events: readonly ScenarioEvent[] = [], sourceSupportedAllergies: readonly string[] = []): OperationalScenarioPackage {
  return {
    id: entry.code,
    title: `${entry.name} — ${entry.diagnosis}`,
    version: "2.4.2",
    validationStatus: "PENDING_VALIDATION",
    patient: { id: entry.code, name: entry.name, ageYears: param(entry.ageYears), weightKg: param(entry.weightKg) },
    initialState: state,
    learningObjectives: commonObjectives,
    actions: actionMap(),
    events,
    catalog: entry,
    sourceFacts,
    sourceSupportedAllergies,
    executableMedicationLogic: false,
    clinicalValidationRequired: true,
  };
}

const fact = (id: string, text: string): ScenarioSourceFact => ({ id, text, source: "FILE-05", status: "SOURCE_TRANSCRIPTION" });

const scenarios: OperationalScenarioPackage[] = [
  makeScenario(ScenarioCatalog[0]!, baseState({ respiratory:{rate:48,oxygenSaturation:89,effort:"severe",airflow:"reduced"}, cardiovascular:{heartRate:144,systolicBP:108,diastolicBP:66,capillaryRefillSeconds:3}, pain:{score:3,scale:"Wong-Baker FACES"}, hydration:{status:"adequate"}, temperatureC:37.6 }), [fact("RANA-VITALS","HR 144; RR 48; BP 108/66; SpO2 89%; Temp 37.6 C; Pain 3/10; CRT 3 s."), fact("RANA-CURVE-3","At minute 3, parental distress/attempted oral fluids is specified as an aspiration-risk curveball."), fact("RANA-CURVE-6","At minute 6, SpO2 86% and silent chest are specified in the source file.")], [
    {id:"RANA-CURVE-3",once:true,trigger:{type:"time",atSeconds:180},execute:s=>{s.flags.parentalAspirationRisk=true;}},
    {id:"RANA-CURVE-6",once:true,trigger:{type:"time",atSeconds:360},execute:s=>{s.respiratory.oxygenSaturation=86;s.respiratory.airflow="markedly_reduced";s.respiratory.effort="severe";s.flags.silentChest=true;}}
  ]),
  makeScenario(ScenarioCatalog[1]!, baseState({ respiratory:{rate:46,oxygenSaturation:89,effort:"severe",airflow:"reduced"}, cardiovascular:{heartRate:142,systolicBP:110,diastolicBP:68,capillaryRefillSeconds:3}, pain:{score:3,scale:"Wong-Baker FACES"}, hydration:{status:"adequate"}, temperatureC:37.8 }), [fact("CHARLIE-ALLERGY","Penicillin allergy is specified."), fact("CHARLIE-VITALS","HR 142; RR 46; BP 110/68; SpO2 89%; Temp 37.8 C; Pain 3/10; CRT 3 s."), fact("CHARLIE-LABS","pH 7.33; pCO2 44; pO2 64; WBC 11,200/uL."), fact("CHARLIE-CURVE-4","At minute 4, sinus tachycardia up to 168 bpm after albuterol is specified.")], [{id:"CHARLIE-CURVE-4",once:true,trigger:{type:"time",atSeconds:240},execute:s=>{s.cardiovascular.heartRate=168;s.flags.albuterolTachycardia=true;}}], ["Penicillin"]),
  makeScenario(ScenarioCatalog[2]!, baseState({ respiratory:{rate:30,oxygenSaturation:91,effort:"increased",airflow:"normal"}, cardiovascular:{heartRate:135,systolicBP:102,diastolicBP:62,capillaryRefillSeconds:3.5}, pain:{score:9,scale:"project-specified"}, hydration:{status:"possible_deficit"}, temperatureC:38.4 }), [fact("BRITTANY-VITALS","HR 135; RR 30; BP 102/62; SpO2 91%; Temp 38.4 C; Pain 9/10; CRT 3.5 s."), fact("BRITTANY-PRESENTATION","Acute vaso-occlusive pain crisis with severe bone/joint pain is specified.")]),
  makeScenario(ScenarioCatalog[3]!, baseState({ respiratory:{rate:32,oxygenSaturation:97,effort:"normal",airflow:"normal"}, cardiovascular:{heartRate:148,systolicBP:88,diastolicBP:54,capillaryRefillSeconds:4}, pain:{score:null,scale:null}, hydration:{status:"significant_deficit"}, temperatureC:38.6 }), [fact("EVA-VITALS","HR 148; RR 32; BP 88/54; SpO2 97%; Temp 38.6 C; CRT 4 s."), fact("EVA-LABS","Na 132; K 3.4; HCO3 15; urine specific gravity 1.032."), fact("EVA-SAFETY","The source specifies no IV potassium until urine output/renal function are confirmed.")]),
  makeScenario(ScenarioCatalog[4]!, baseState({ respiratory:{rate:14,oxygenSaturation:86,effort:"severe",airflow:"markedly_reduced"}, cardiovascular:{heartRate:162,systolicBP:118,diastolicBP:76,capillaryRefillSeconds:null}, pain:{score:null,scale:null}, hydration:{status:"unknown"}, temperatureC:39.4 }), [fact("JACKSON-VITALS","HR 162; RR 14 irregular/shallow with snoring; BP 118/76; SpO2 86%; Temp 39.4 C."), fact("JACKSON-PRESENTATION","Generalized convulsive activity, upward eye deviation, circumoral cyanosis and oral secretions are specified."), fact("JACKSON-SAFETY","The source specifies left-lateral positioning and no object in the mouth.")]),
  makeScenario(ScenarioCatalog[5]!, baseState({ respiratory:{rate:42,oxygenSaturation:90,effort:"severe",airflow:"reduced"}, cardiovascular:{heartRate:152,systolicBP:92,diastolicBP:52,capillaryRefillSeconds:3.5}, pain:{score:null,scale:null}, hydration:{status:"possible_deficit"}, temperatureC:39.8 }), [fact("SABRINA-VITALS","HR 152; RR 42; BP 92/52; SpO2 90%; Temp 39.8 C; CRT 3.5 s."), fact("SABRINA-LABS","WBC 21,800/uL; CRP 112 mg/L; lactate 3.1 mmol/L."), fact("SABRINA-FINDINGS","Right lower-lobe moist crackles/bronchial breath sounds and consolidation are specified.")]),
  makeScenario(ScenarioCatalog[6]!, baseState({ respiratory:{rate:34,oxygenSaturation:94,effort:"increased",airflow:"normal"}, cardiovascular:{heartRate:158,systolicBP:86,diastolicBP:48,capillaryRefillSeconds:4}, pain:{score:null,scale:null}, hydration:{status:"possible_deficit"}, temperatureC:null }), [fact("ETHAN-VITALS","HR 158; RR 34; BP 86/48; SpO2 94%; CRT 4 s."), fact("ETHAN-RED-FLAG","Frequent swallowing/throat clearing is specified as a cardinal warning sign."), fact("ETHAN-EVENT","The source specifies fresh hematemesis and an emergency response pathway.")]),
  makeScenario(ScenarioCatalog[7]!, baseState({ respiratory:{rate:48,oxygenSaturation:87,effort:"severe",airflow:"markedly_reduced"}, cardiovascular:{heartRate:165,systolicBP:78,diastolicBP:42,capillaryRefillSeconds:4}, pain:{score:null,scale:null}, hydration:{status:"possible_deficit"}, temperatureC:null }), [fact("OLIVIA-VITALS","HR 165; RR 48; BP 78/42; SpO2 87%; CRT 4 s."), fact("OLIVIA-FINDINGS","Stridor, angioedema and generalized urticaria are specified."), fact("OLIVIA-PRIORITY","The source identifies immediate epinephrine as the first priority; medication execution remains disabled pending validated order-set review.")]),
  makeScenario(ScenarioCatalog[8]!, baseState({ respiratory:{rate:62,oxygenSaturation:64,effort:"severe",airflow:"markedly_reduced"}, cardiovascular:{heartRate:178,systolicBP:74,diastolicBP:40,capillaryRefillSeconds:null}, pain:{score:null,scale:null}, hydration:{status:"unknown"}, temperatureC:null }), [fact("SARAH-VITALS","HR 178; RR 62; BP 74/40; SpO2 64%."), fact("SARAH-PATHOPHYS","The source describes Tet spell physiology and right-to-left shunting."), fact("SARAH-PRIORITY","Knee-chest positioning is identified as the critical non-pharmacological intervention in the source.")]),
  makeScenario(ScenarioCatalog[9]!, baseState({ respiratory:{rate:14,oxygenSaturation:95,effort:"severe",airflow:"reduced"}, cardiovascular:{heartRate:52,systolicBP:146,diastolicBP:58,capillaryRefillSeconds:null}, pain:{score:null,scale:null}, hydration:{status:"unknown"}, temperatureC:37.2 }), [fact("TOMMY-VITALS","HR 52; RR 14 irregular; BP 146/58; SpO2 95%; Temp 37.2 C."), fact("TOMMY-NEURO","GCS 9/15 and unilateral abnormal pupil findings are specified."), fact("TOMMY-PRIORITY","Head-of-bed elevation with midline head position and avoidance of neck flexion are specified; medication execution remains disabled pending validation.")]),
  makeScenario(ScenarioCatalog[10]!, baseState({ respiratory:{rate:40,oxygenSaturation:90,effort:"increased",airflow:"reduced"}, cardiovascular:{heartRate:138,systolicBP:102,diastolicBP:60,capillaryRefillSeconds:3}, pain:{score:5,scale:"project-specified"}, hydration:{status:"possible_deficit"}, temperatureC:39.2 }), [fact("PEYTON-VITALS","HR 138; RR 40; BP 102/60; SpO2 90%; Temp 39.2 C; Pain 5/10; CRT 3 s."), fact("PEYTON-FINDINGS","Fine crackles at the right lung base with diminished breath sounds and pleuritic pain are specified."), fact("PEYTON-ORDERS","Blood cultures before ceftriaxone and oxygen targeting SpO2 >=94% are specified; medication execution remains disabled pending validation.")]),
];

export const OperationalScenarioPackages: readonly OperationalScenarioPackage[] = scenarios;
export const OperationalScenarioById: ReadonlyMap<string, OperationalScenarioPackage> = new Map(scenarios.map(s => [s.id, s]));

export function getOperationalScenario(id: string): OperationalScenarioPackage | undefined {
  return OperationalScenarioById.get(id);
}
