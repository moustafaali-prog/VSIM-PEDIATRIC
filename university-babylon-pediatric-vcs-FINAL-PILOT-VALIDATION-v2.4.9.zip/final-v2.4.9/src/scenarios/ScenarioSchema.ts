import type {ClinicalState} from "../clinical/ClinicalState";
import type {ScenarioEvent} from "../core/EventEngine";
export type ValidationStatus="VERIFIED"|"SCENARIO_SPECIFIC"|"PENDING_VALIDATION"|"UNSUPPORTED"|"CONFLICT";
export interface ValidatedParameter<T>{value:T;unit?:string;source:"PROJECT_FILE"|"GUIDELINE"|"LITERATURE"|"MODEL"|"SCENARIO_SPECIFIC";sourceId:string;validationStatus:ValidationStatus;notes?:string}
export interface ScenarioDefinition{
 id:string;title:string;version:string;validationStatus:ValidationStatus;
 patient:{id:string;name:string;ageYears:ValidatedParameter<number>;weightKg:ValidatedParameter<number>};
 initialState:ClinicalState;learningObjectives:string[];
 actions:Record<string,(s:ClinicalState)=>void>;events:readonly ScenarioEvent[];
}