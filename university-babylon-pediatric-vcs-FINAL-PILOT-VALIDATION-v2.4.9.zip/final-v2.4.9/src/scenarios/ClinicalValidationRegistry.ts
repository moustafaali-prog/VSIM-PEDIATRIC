/**
 * Clinical validation registry.
 *
 * This registry records provenance and review state; it does not declare
 * clinical approval. Project-file values remain transcriptions until a
 * qualified clinical SME reviews and approves them.
 */
export type ClinicalValidationStatus =
  | "SOURCE_TRANSCRIPTION"
  | "EVIDENCE_REVIEWED"
  | "SME_APPROVED"
  | "REQUIRES_REVISION";

export interface ClinicalValidationRecord {
  scenarioId: string;
  elementId: string;
  elementType: "DEMOGRAPHICS" | "BASELINE_STATE" | "EVENT" | "ASSESSMENT" | "INTERVENTION" | "MEDICATION" | "AUDIO";
  sourceDocument: "FILE-05" | "FILE-04" | "FILE-07";
  implementationRef: string;
  status: ClinicalValidationStatus;
  executable: boolean;
  reviewNote: string;
}

const scenarios = [
  "rana-kadhim", "charlie-snow", "brittany-long", "eva-madison", "jackson-weber",
  "sabrina-vasquez", "ethan-williams", "olivia-jones", "sarah-davis", "tommy-evans", "peyton-harris"
] as const;

const records: ClinicalValidationRecord[] = scenarios.flatMap((scenarioId) => [
  {
    scenarioId,
    elementId: `${scenarioId.toUpperCase()}-DEMOGRAPHICS`,
    elementType: "DEMOGRAPHICS",
    sourceDocument: "FILE-05",
    implementationRef: "src/scenarios/ScenarioCatalog.ts",
    status: "SOURCE_TRANSCRIPTION",
    executable: false,
    reviewNote: "Age, weight, diagnosis and scenario identity are transcribed from FILE-05; clinical approval is pending."
  },
  {
    scenarioId,
    elementId: `${scenarioId.toUpperCase()}-BASELINE`,
    elementType: "BASELINE_STATE",
    sourceDocument: "FILE-05",
    implementationRef: "src/scenarios/ScenarioPackage.ts",
    status: "SOURCE_TRANSCRIPTION",
    executable: false,
    reviewNote: "Baseline physiologic values are preserved from the project source and require clinical review before certification."
  },
  {
    scenarioId,
    elementId: `${scenarioId.toUpperCase()}-CRITERIA`,
    elementType: "ASSESSMENT",
    sourceDocument: "FILE-04",
    implementationRef: "src/scenarios/ScenarioClinicalMap.ts",
    status: "SOURCE_TRANSCRIPTION",
    executable: false,
    reviewNote: "Assessment/scoring criteria are project-defined and remain subject to simulation-design and clinical SME review."
  },
  {
    scenarioId,
    elementId: `${scenarioId.toUpperCase()}-MEDICATIONS`,
    elementType: "MEDICATION",
    sourceDocument: "FILE-05",
    implementationRef: "src/scenarios/ScenarioPackage.ts",
    status: "REQUIRES_REVISION",
    executable: false,
    reviewNote: "Medication/order execution is intentionally disabled until medication, dose, route, timing and contraindication logic are clinically validated."
  }
]);

export const ClinicalValidationRegistry: readonly ClinicalValidationRecord[] = records;

export function getClinicalValidationRecords(scenarioId: string): readonly ClinicalValidationRecord[] {
  return ClinicalValidationRegistry.filter((record) => record.scenarioId === scenarioId);
}

export function isScenarioClinicallyApproved(scenarioId: string): boolean {
  const rows = getClinicalValidationRecords(scenarioId);
  return rows.length > 0 && rows.every((row) => row.status === "SME_APPROVED");
}

export function assertExecutableMedicationSafety(): void {
  const medicationRows = ClinicalValidationRegistry.filter((row) => row.elementType === "MEDICATION");
  if (medicationRows.some((row) => row.executable || row.status === "SME_APPROVED")) {
    throw new Error("MEDICATION_EXECUTION_REQUIRES_EXPLICIT_VALIDATED_ORDER_SET");
  }
}
