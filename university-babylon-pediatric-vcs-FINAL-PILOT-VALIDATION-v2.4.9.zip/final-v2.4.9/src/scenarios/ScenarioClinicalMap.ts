import type { ClinicalActionId } from "../clinical/ActionTypes";
import type { CJMMStage } from "../assessment/CJMMEngine";

export interface ScenarioCriterion {
  id: string;
  actionId: ClinicalActionId;
  domain: "safety" | "assessment" | "interventions" | "emergency" | "communication";
  cjmmStage: CJMMStage;
  points: number;
  source: "FILE-04" | "FILE-05" | "FILE-07";
  sourceNote: string;
  validationStatus: "SOURCE_SUPPORTED" | "PENDING_CLINICAL_VALIDATION";
}

export interface ScenarioClinicalMap {
  scenarioId: string;
  criteria: readonly ScenarioCriterion[];
  eventCriteria: readonly { eventId: string; actionIds: readonly ClinicalActionId[]; domain: "emergency"; points: number; source: "FILE-05"; sourceNote: string; }[];
}

const commonSafety: ScenarioCriterion[] = [
  { id:"SAFE-HAND", actionId:"hand_hygiene", domain:"safety", cjmmStage:"take_action", points:2, source:"FILE-04", sourceNote:"Mandatory hand hygiene safety gate.", validationStatus:"SOURCE_SUPPORTED" },
  { id:"SAFE-ID", actionId:"identify_patient", domain:"safety", cjmmStage:"take_action", points:2, source:"FILE-04", sourceNote:"Two-identifier patient verification.", validationStatus:"SOURCE_SUPPORTED" },
  { id:"SAFE-ALLERGY", actionId:"check_allergies", domain:"safety", cjmmStage:"take_action", points:2, source:"FILE-04", sourceNote:"Allergy cross-check before intervention.", validationStatus:"SOURCE_SUPPORTED" },
];

const commonAssessment: ScenarioCriterion[] = [
  { id:"ASSESS-EHR", actionId:"review_ehr", domain:"assessment", cjmmStage:"recognize_cues", points:3, source:"FILE-07", sourceNote:"Stage 1 EHR review.", validationStatus:"SOURCE_SUPPORTED" },
  { id:"ASSESS-VITALS", actionId:"initial_vitals", domain:"assessment", cjmmStage:"recognize_cues", points:4, source:"FILE-07", sourceNote:"Stage 3 initial PAT/vital assessment.", validationStatus:"SOURCE_SUPPORTED" },
  { id:"ASSESS-LUNG", actionId:"auscultate_lungs", domain:"assessment", cjmmStage:"analyze_cues", points:3, source:"FILE-07", sourceNote:"Stage 4 lung auscultation.", validationStatus:"SOURCE_SUPPORTED" },
  { id:"ASSESS-CRT", actionId:"capillary_refill", domain:"assessment", cjmmStage:"analyze_cues", points:2, source:"FILE-07", sourceNote:"Stage 4 perfusion assessment.", validationStatus:"SOURCE_SUPPORTED" },
];

const commonEvaluation: ScenarioCriterion[] = [
  { id:"EVAL-VITALS", actionId:"reassess_vitals", domain:"assessment", cjmmStage:"evaluate_outcomes", points:4, source:"FILE-07", sourceNote:"Stage 5/8 reassessment requirement.", validationStatus:"SOURCE_SUPPORTED" },
  { id:"COMM-DOC", actionId:"document", domain:"communication", cjmmStage:"evaluate_outcomes", points:2, source:"FILE-07", sourceNote:"Documentation is part of the student workflow.", validationStatus:"SOURCE_SUPPORTED" },
  { id:"COMM-SBAR", actionId:"sbar_handover", domain:"communication", cjmmStage:"evaluate_outcomes", points:2, source:"FILE-07", sourceNote:"Stage 7 SBAR handover.", validationStatus:"SOURCE_SUPPORTED" },
];

function map(scenarioId: string, extras: ScenarioCriterion[] = [], eventCriteria: ScenarioClinicalMap["eventCriteria"] = []): ScenarioClinicalMap {
  return { scenarioId, criteria: [...commonSafety, ...commonAssessment, ...extras, ...commonEvaluation], eventCriteria };
}

export const ScenarioClinicalMaps: Readonly<Record<string, ScenarioClinicalMap>> = {
  "rana-kadhim": map("rana-kadhim", [
    {id:"RANA-PAT",actionId:"pat_assessment",domain:"assessment",cjmmStage:"recognize_cues",points:3,source:"FILE-07",sourceNote:"PAT is mandatory in the workflow.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"RANA-FOWLER",actionId:"position_high_fowler",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-04",sourceNote:"Head-of-bed elevation is a critical action for acute respiratory distress.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"RANA-O2",actionId:"apply_oxygen",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-05",sourceNote:"Oxygenation is explicitly specified in the scenario.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"RANA-NEB",actionId:"start_nebulizer",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-05",sourceNote:"Nebulized bronchodilator therapy is explicitly specified; medication execution remains validation-gated.",validationStatus:"PENDING_CLINICAL_VALIDATION"},
    {id:"RANA-EMERG",actionId:"call_emergency_team",domain:"emergency",cjmmStage:"prioritize_hypotheses",points:3,source:"FILE-05",sourceNote:"Emergency-team escalation is specified at the critical curveball.",validationStatus:"SOURCE_SUPPORTED"},
  ], [{eventId:"RANA-CURVE-3",actionIds:["document"],domain:"emergency",points:2,source:"FILE-05",sourceNote:"Minute-3 aspiration-risk curveball requires response; no automatic clinical response is inferred."},{eventId:"RANA-CURVE-6",actionIds:["apply_oxygen","call_emergency_team"],domain:"emergency",points:4,source:"FILE-05",sourceNote:"Minute-6 deterioration specifies oxygen escalation and emergency response."}]),
  "charlie-snow": map("charlie-snow", [
    {id:"CHARLIE-PAT",actionId:"pat_assessment",domain:"assessment",cjmmStage:"recognize_cues",points:3,source:"FILE-07",sourceNote:"PAT is mandatory in the workflow.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"CHARLIE-FOWLER",actionId:"position_high_fowler",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-04",sourceNote:"Head-of-bed elevation is specified for acute respiratory distress.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"CHARLIE-O2",actionId:"apply_oxygen",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-05",sourceNote:"Oxygenation is explicitly specified.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"CHARLIE-NEB",actionId:"start_nebulizer",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-05",sourceNote:"Albuterol/ipratropium nebulization is specified; medication execution remains validation-gated.",validationStatus:"PENDING_CLINICAL_VALIDATION"},
  ], [{eventId:"CHARLIE-CURVE-4",actionIds:["reassess_vitals","document"],domain:"emergency",points:3,source:"FILE-05",sourceNote:"Minute-4 tachycardia curveball requires reassessment and documentation; no drug-effect adjustment is inferred."}]),
  "brittany-long": map("brittany-long", [
    {id:"BRITTANY-O2",actionId:"apply_oxygen",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-05",sourceNote:"Oxygenation target is explicitly specified.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"BRITTANY-REASSESS",actionId:"reassess_vitals",domain:"emergency",cjmmStage:"evaluate_outcomes",points:3,source:"FILE-05",sourceNote:"Acute chest syndrome curveball requires recognition/reassessment; no treatment effect is inferred.",validationStatus:"SOURCE_SUPPORTED"},
  ], [{eventId:"BRITTANY-CURVE-5",actionIds:["reassess_vitals","call_emergency_team"],domain:"emergency",points:4,source:"FILE-05",sourceNote:"Minute-5 acute chest syndrome deterioration is explicitly specified; escalation action is kept separate from drug execution."}]),
  "eva-madison": map("eva-madison", [
    {id:"EVA-LABS",actionId:"review_labs",domain:"assessment",cjmmStage:"analyze_cues",points:4,source:"FILE-05",sourceNote:"Electrolyte/renal laboratory review is explicitly ordered.",validationStatus:"SOURCE_SUPPORTED"},
  ]),
  "jackson-weber": map("jackson-weber", [
    {id:"JACKSON-LATERAL",actionId:"position_left_lateral",domain:"interventions",cjmmStage:"take_action",points:5,source:"FILE-05",sourceNote:"Left-lateral positioning is explicitly specified for seizure safety.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"JACKSON-O2",actionId:"apply_oxygen",domain:"interventions",cjmmStage:"take_action",points:3,source:"FILE-05",sourceNote:"Oxygen is explicitly specified.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"JACKSON-SUCTION",actionId:"oral_suction",domain:"interventions",cjmmStage:"take_action",points:3,source:"FILE-05",sourceNote:"Oral suction is explicitly specified; no deep-airway technique is inferred.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"JACKSON-NEURO",actionId:"reassess_neuro",domain:"assessment",cjmmStage:"evaluate_outcomes",points:3,source:"FILE-07",sourceNote:"Neurological reassessment is included in the workflow.",validationStatus:"SOURCE_SUPPORTED"},
  ]),
  "sabrina-vasquez": map("sabrina-vasquez", [
    {id:"SABRINA-LABS",actionId:"review_labs",domain:"assessment",cjmmStage:"analyze_cues",points:4,source:"FILE-05",sourceNote:"CBC/CRP/lactate laboratory findings are specified.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"SABRINA-O2",actionId:"apply_oxygen",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-05",sourceNote:"Oxygenation is part of the scenario management pathway.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"SABRINA-CULTURES",actionId:"obtain_blood_cultures",domain:"interventions",cjmmStage:"generate_solutions",points:4,source:"FILE-05",sourceNote:"Blood cultures before antimicrobial therapy are specified in the scenario source.",validationStatus:"SOURCE_SUPPORTED"},
  ]),
  "ethan-williams": map("ethan-williams", [
    {id:"ETHAN-NPO",actionId:"maintain_npo",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-05",sourceNote:"Emergency pathway specifies withholding oral intake.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"ETHAN-EMERG",actionId:"call_emergency_team",domain:"emergency",cjmmStage:"prioritize_hypotheses",points:5,source:"FILE-05",sourceNote:"Emergency response is explicitly specified.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"ETHAN-VITALS",actionId:"reassess_vitals",domain:"emergency",cjmmStage:"evaluate_outcomes",points:3,source:"FILE-07",sourceNote:"Continuous monitoring/reassessment is required.",validationStatus:"SOURCE_SUPPORTED"},
  ]),
  "olivia-jones": map("olivia-jones", [
    {id:"OLIVIA-EMERG",actionId:"call_emergency_team",domain:"emergency",cjmmStage:"prioritize_hypotheses",points:5,source:"FILE-05",sourceNote:"Emergency escalation is required; medication execution remains validation-gated.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"OLIVIA-O2",actionId:"apply_oxygen",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-05",sourceNote:"Oxygenation is part of the emergency pathway.",validationStatus:"SOURCE_SUPPORTED"},
  ]),
  "sarah-davis": map("sarah-davis", [
    {id:"SARAH-KNEE",actionId:"position_knee_chest",domain:"emergency",cjmmStage:"take_action",points:6,source:"FILE-05",sourceNote:"Knee-chest positioning is explicitly identified as the critical non-pharmacological intervention.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"SARAH-O2",actionId:"apply_oxygen",domain:"interventions",cjmmStage:"take_action",points:3,source:"FILE-05",sourceNote:"Oxygen is explicitly specified.",validationStatus:"SOURCE_SUPPORTED"},
  ]),
  "tommy-evans": map("tommy-evans", [
    {id:"TOMMY-PUPIL",actionId:"pupil_exam",domain:"assessment",cjmmStage:"recognize_cues",points:4,source:"FILE-05",sourceNote:"Abnormal pupil findings and neurological assessment are specified.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"TOMMY-FOWLER",actionId:"position_high_fowler",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-05",sourceNote:"Head-of-bed elevation with midline positioning is specified.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"TOMMY-NEURO",actionId:"reassess_neuro",domain:"assessment",cjmmStage:"evaluate_outcomes",points:4,source:"FILE-07",sourceNote:"Neurological reassessment is part of the workflow.",validationStatus:"SOURCE_SUPPORTED"},
  ]),
  "peyton-harris": map("peyton-harris", [
    {id:"PEYTON-LUNG",actionId:"auscultate_lungs",domain:"assessment",cjmmStage:"analyze_cues",points:4,source:"FILE-05",sourceNote:"Right-base crackles/diminished breath sounds are specified.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"PEYTON-CULTURES",actionId:"obtain_blood_cultures",domain:"interventions",cjmmStage:"generate_solutions",points:4,source:"FILE-05",sourceNote:"Blood cultures before ceftriaxone are specified; medication execution remains validation-gated.",validationStatus:"SOURCE_SUPPORTED"},
    {id:"PEYTON-O2",actionId:"apply_oxygen",domain:"interventions",cjmmStage:"take_action",points:4,source:"FILE-05",sourceNote:"Oxygen target is specified in the scenario source.",validationStatus:"SOURCE_SUPPORTED"},
  ]),
};

export function getScenarioClinicalMap(scenarioId: string): ScenarioClinicalMap | undefined { return ScenarioClinicalMaps[scenarioId]; }
