export type MedicationValidationStatus =
  | "SOURCE_IDENTIFIED"
  | "EVIDENCE_REVIEWED"
  | "REQUIRES_SME"
  | "SME_APPROVED"
  | "REQUIRES_REVISION";

export interface MedicationOrderValidationRow {
  scenarioId: string;
  elementId: string;
  sourceProject: string;
  externalEvidenceFamilies: readonly string[];
  implementationRef: string;
  executable: boolean;
  status: MedicationValidationStatus;
  requiredChecks: readonly string[];
  reviewNote: string;
}

const checks = [
  "indication",
  "patient-specific weight/age applicability",
  "route",
  "dose/order parameters",
  "timing/frequency",
  "contraindications/allergies",
  "interaction/duplication",
  "monitoring requirements",
  "expected response",
  "escalation/stop criteria",
  "local institutional compatibility",
] as const;

/**
 * Provenance/control registry only. It intentionally contains no executable
 * medication doses and no treatment-effect coefficients.
 */
export const MedicationOrderValidationRegistry: readonly MedicationOrderValidationRow[] = [
  {scenarioId:"BABYLON-PED-01",elementId:"RANA-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["GINA-2026"],implementationRef:"ScenarioClinicalMap:RANA",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"Source-supported medication intent is retained, but executable order logic requires clinical reconciliation."},
  {scenarioId:"VSIM-PED-02",elementId:"CHARLIE-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["GINA-2026"],implementationRef:"ScenarioClinicalMap:CHARLIE",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"Project source contains medication-related scenario content; executable logic remains locked."},
  {scenarioId:"VSIM-PED-03",elementId:"BRITTANY-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["WHO-SCD-2026"],implementationRef:"ScenarioClinicalMap:BRITTANY",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"SCD medication/order content requires reconciliation with current pediatric SCD guidance and local protocol."},
  {scenarioId:"VSIM-PED-04",elementId:"EVA-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["PEDIATRIC-GASTROENTERITIS-EVIDENCE"],implementationRef:"ScenarioClinicalMap:EVA",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"Order content remains non-executable pending clinical review."},
  {scenarioId:"VSIM-PED-05",elementId:"JACKSON-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["AHA-AAP-PALS-2025","AES-STATUS-EPILEPTICUS"],implementationRef:"ScenarioClinicalMap:JACKSON",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"Emergency medication/order logic requires current pediatric emergency review."},
  {scenarioId:"VSIM-PED-06",elementId:"SABINA-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["GINA-2026"],implementationRef:"ScenarioClinicalMap:SABINA",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"Asthma medication/order logic remains locked pending reconciliation with current guidance."},
  {scenarioId:"VSIM-PED-07",elementId:"PEYTON-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["IDSA-PIDS-CAP-2026","SCCM-PEDIATRIC-SEPSIS-2026"],implementationRef:"ScenarioClinicalMap:PEYTON",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"Antimicrobial and sepsis-related order logic requires current guideline and local-protocol review."},
  {scenarioId:"VSIM-PED-08",elementId:"ETHAN-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["AHA-AAP-PALS-2025","AAO-HNS-POST-TONSILLECTOMY"],implementationRef:"ScenarioClinicalMap:ETHAN",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"Postoperative emergency order logic remains locked."},
  {scenarioId:"VSIM-PED-09",elementId:"OLIVIA-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["ANAPHYLAXIS-GUIDANCE","AHA-AAP-PALS-2025"],implementationRef:"ScenarioClinicalMap:OLIVIA",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"Emergency medication priority is source-supported, but executable order logic requires SME approval."},
  {scenarioId:"VSIM-PED-10",elementId:"SARAH-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["AHA-AAP-PALS-2025"],implementationRef:"ScenarioClinicalMap:SARAH",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"Tet-spell emergency medication/order logic requires clinical reconciliation."},
  {scenarioId:"VSIM-PED-11",elementId:"TOMMY-MED-ORDERS",sourceProject:"FILE-05",externalEvidenceFamilies:["PEDIATRIC-TBI-GUIDANCE","AHA-AAP-PALS-2025"],implementationRef:"ScenarioClinicalMap:TOMMY",executable:false,status:"REQUIRES_SME",requiredChecks:checks,reviewNote:"Head-injury medication/order logic remains locked pending clinical review."},
] as const;

export function assertMedicationExecutionLocked(): void {
  if (MedicationOrderValidationRegistry.some((row) => row.executable)) {
    throw new Error("MEDICATION_ORDER_EXECUTION_MUST_REMAIN_LOCKED");
  }
}

export function assertNoApprovedExecutableOrderSet(): void {
  if (MedicationOrderValidationRegistry.some((row) => row.status === "SME_APPROVED" && row.executable)) {
    throw new Error("SME_APPROVED_ORDER_SET_CANNOT_BE_EXECUTABLE_WITHOUT_RELEASE_GATE");
  }
}
