import type {EndToEndSession} from "../core/EndToEndSession";
import {SceneManager} from "../scene/SceneManager";
import {TelemetryPanel} from "./TelemetryPanel";
import {detectDeviceProfile} from "../platform/DeviceProfile";
import { InteractionActionRouter } from "../interaction/InteractionActionRouter";
import { getInteraction } from "../scene/InteractionRegistry";
export class SimulationUI{
 private scene?:SceneManager; private telemetry?:TelemetryPanel; private running=true; private interaction?:InteractionActionRouter;
 constructor(private root:HTMLElement,private session:EndToEndSession){}
 private get runtime(){ return this.session.runtime; }
 private get controller(){ return this.runtime.controller; }
 mount(){
  const profile=detectDeviceProfile();
  this.root.innerHTML="";
  this.root.className="pediatric-vcs-app"; this.root.setAttribute("data-testid","pediatric-vcs-app");
  this.root.style.cssText="height:100vh;margin:0;font-family:system-ui,sans-serif;background:#10151b;color:white;overflow:hidden";
  const style=document.createElement("style");
  style.textContent=`
    .pediatric-vcs-app{display:grid;grid-template-columns:minmax(0,3fr) minmax(320px,2fr)}
    .pediatric-vcs-app section{min-width:0;min-height:0;position:relative;touch-action:none}
    .pediatric-vcs-app aside{min-width:0;min-height:0;padding:14px;overflow:auto;overscroll-behavior:contain}
    .pediatric-vcs-app button{touch-action:manipulation;min-height:44px;font-size:14px}
    @media (max-width: 900px){.pediatric-vcs-app{grid-template-columns:1fr;grid-template-rows:minmax(52vh,1fr) minmax(0,48vh)}}
    @media (max-width: 600px){.pediatric-vcs-app{grid-template-rows:minmax(48vh,1fr) minmax(0,52vh)}.pediatric-vcs-app aside{padding:10px}.pediatric-vcs-app h2{font-size:18px}}
  `;
  document.head.appendChild(style);
  const view=document.createElement("section"),panel=document.createElement("aside"); view.setAttribute("data-testid","simulation-scene"); panel.setAttribute("data-testid","simulation-panel"); this.root.append(view,panel);
  this.scene=new SceneManager(view);this.telemetry=new TelemetryPanel(panel);
  this.interaction=new InteractionActionRouter(this.runtime);
  this.interaction.procedures.onVisualState((state)=>this.scene?.setProcedureVisualState(state));
  this.scene.onClinicalAction((actionId,target)=>{ this.interaction?.procedures.begin(actionId,target.objectName); });
  const title=document.createElement("h2");title.setAttribute("data-testid","simulation-title");title.textContent="University of Babylon — Pediatric VCS";panel.prepend(title);
  const device=document.createElement("div");device.setAttribute("data-testid","device-profile");device.textContent=`Device: ${profile.className} · Quality: ${profile.recommendedQuality}`;panel.append(device);
  const ehrBtn=this.button("Review EHR",()=>{const accepted=this.session.perform("review_ehr");const e=this.session.snapshot().ehr;alert(`${accepted?"EHR reviewed":"EHR review blocked"}. Patient: ${e.patient.displayName}`);});panel.append(ehrBtn);
  const actions:[string,string][]=[
   ["hand_hygiene","Hand hygiene"],["identify_patient","Identify patient"],["check_allergies","Check allergies"],["initial_vitals","Initial vitals"],["pat_assessment","PAT assessment"],["auscultate_lungs","Auscultate lungs"],["auscultate_heart","Auscultate heart"],["pupil_exam","PERRLA"],["capillary_refill","Capillary refill"],["position_high_fowler","High Fowler"],["apply_oxygen","Apply oxygen"],["start_nebulizer","Start nebulizer"],["reassess_vitals","Reassess vitals"],["document","Document"],["sbar_handover","SBAR handover"]
  ];
  for(const [id,label] of actions)panel.append(this.button(label,()=>this.runAction(id as import("../clinical/ActionTypes").ClinicalActionId)));
  const status=document.createElement("pre");panel.append(status);
  const score=document.createElement("pre");panel.append(score);
  const loop=(now:number)=>{const last=(this as any)._last??now;(this as any)._last=now;const dt=Math.min(.1,Math.max(0,(now-last)/1000));if(this.running){this.session.tick(dt);this.interaction?.procedures.update(dt);}const s=this.controller.getState();this.scene?.updateFromClinicalState(s,dt);this.scene?.render();this.telemetry?.update(s);status.textContent=`t=${s.timeSeconds.toFixed(1)}s\nPosition: ${s.position}\nEffort: ${s.respiratory.effort}\nAirflow: ${s.respiratory.airflow}\nSpO₂: ${s.respiratory.oxygenSaturation ?? "—"}\nScenario: ${this.controller.scenarioEngine.getScenario().id}`;
  const a=this.controller.assessment.snapshot();const completion=this.session.snapshot().completion;score.textContent=`Performance: ${a.performanceTotal.toFixed(2)}\nCJMM: ${a.cjmmTotal.toFixed(2)}\nCompleted criteria: ${a.completedCriteria.length}\nValidation-blocked: ${a.validationBlockedCriteria.length}\nReady for debrief: ${completion.readyForDebrief}`;requestAnimationFrame(loop)};
  const pause=this.button("Pause",()=>{this.running=!this.running;pause.textContent=this.running?"Pause":"Resume"});panel.append(pause);requestAnimationFrame(loop);
  addEventListener("resize",()=>this.scene?.resize(view.clientWidth,view.clientHeight));
 }
 private runAction(actionId: import("../clinical/ActionTypes").ClinicalActionId): void {
  const def=getInteraction(actionId);
  if(def?.procedure){ this.interaction?.procedures.begin(actionId,def.target); return; }
  this.controller.dispatchAction(actionId);
 }
 private button(text:string,onClick:()=>void){const b=document.createElement("button");b.type="button";b.dataset.action=text.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");b.textContent=text;b.onclick=onClick;b.style.cssText="display:block;width:100%;margin:5px 0;padding:10px;border:0;border-radius:6px;cursor:pointer";return b;}
}
