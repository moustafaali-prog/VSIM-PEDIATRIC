import type { ClinicalState } from "../clinical/ClinicalState";
import { generateWaveform, type WaveformKind } from "../telemetry/WaveformGenerator";

export interface TelemetryChannel { kind: WaveformKind; samples: ReturnType<typeof generateWaveform>; }
export interface TelemetrySnapshot {
  vitals: { hr: number|null; rr: number|null; spo2: number|null; sbp: number|null; dbp: number|null; temp: number|null; crt: number|null };
  channels: TelemetryChannel[];
}

export function deriveTelemetry(state: Readonly<ClinicalState>): TelemetrySnapshot {
  const input = { heartRate: state.cardiovascular.heartRate, respiratoryRate: state.respiratory.rate, systolicBP: state.cardiovascular.systolicBP, diastolicBP: state.cardiovascular.diastolicBP };
  return {
    vitals: { hr: input.heartRate ?? null, rr: input.respiratoryRate ?? null, spo2: state.respiratory.oxygenSaturation ?? null, sbp: input.systolicBP ?? null, dbp: input.diastolicBP ?? null, temp: state.temperatureC ?? null, crt: state.cardiovascular.capillaryRefillSeconds ?? null },
    channels: (["ECG", "PLETH", "ABP", "CAPNOGRAPHY"] as WaveformKind[]).map(kind => ({ kind, samples: generateWaveform(kind, input, 2, 120) })),
  };
}
