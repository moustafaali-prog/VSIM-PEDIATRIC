import { deriveTelemetry } from "./TelemetryModel";
import type { ClinicalState } from "../clinical/ClinicalState";

export class TelemetryPanel {
  private readonly pre = document.createElement("pre");
  private readonly canvas = document.createElement("canvas");
  private readonly ctx = this.canvas.getContext("2d");
  constructor(private readonly host: HTMLElement) {
    host.append(this.pre, this.canvas);
    this.canvas.width = 640; this.canvas.height = 220;
    this.canvas.style.width = "100%"; this.canvas.style.height = "220px";
  }
  update(s: Readonly<ClinicalState>): void {
    const t = deriveTelemetry(s);
    this.pre.textContent = `HR ${t.vitals.hr ?? "—"}  RR ${t.vitals.rr ?? "—"}  SpO₂ ${t.vitals.spo2 ?? "—"}\nBP ${t.vitals.sbp ?? "—"}/${t.vitals.dbp ?? "—"}  Temp ${t.vitals.temp ?? "—"}  CRT ${t.vitals.crt ?? "—"}`;
    if (!this.ctx) return;
    const ctx = this.ctx; ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    const rows = t.channels.length; const rowH = this.canvas.height / rows;
    t.channels.forEach((channel, row) => {
      ctx.beginPath();
      channel.samples.forEach((p, i) => {
        const x = i / Math.max(1, channel.samples.length - 1) * this.canvas.width;
        const normalized = channel.kind === "ABP" ? (p.value - (t.vitals.dbp ?? 60)) / Math.max(1, (t.vitals.sbp ?? 100) - (t.vitals.dbp ?? 60)) : p.value / (channel.kind === "CAPNOGRAPHY" ? 35 : 1);
        const y = row * rowH + rowH * (0.8 - Math.max(-1, Math.min(1, normalized)) * 0.28);
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      });
      ctx.stroke();
      ctx.fillText(channel.kind, 6, row * rowH + 14);
    });
  }
}
