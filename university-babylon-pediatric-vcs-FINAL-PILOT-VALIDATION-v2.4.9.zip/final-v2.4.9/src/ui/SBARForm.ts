export interface SBARFormData {
  situation: string;
  background: string;
  assessment: string;
  recommendation: string;
}

export function isCompleteSBAR(form: SBARFormData): boolean {
  return [form.situation, form.background, form.assessment, form.recommendation]
    .every(value => value.trim().length > 0);
}
