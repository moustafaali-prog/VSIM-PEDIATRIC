"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildDebrief = buildDebrief;
const SBARReport_1 = require("./SBARReport");
function buildDebrief(state, audit, performance, cjmm) {
    const records = audit.actionRecords();
    const accepted = records.filter((x) => x.accepted);
    const safety = new Set(accepted.map((x) => x.actionId));
    const missedSafetyChecks = ["hand_hygiene", "identify_patient", "check_allergies"]
        .filter((id) => !safety.has(id));
    return {
        performanceScore: Number(performance.total().toFixed(2)),
        cjmmScore: Number(cjmm.total().toFixed(2)),
        sbar: (0, SBARReport_1.buildSBAR)(state, audit.all()),
        actionCount: records.length,
        acceptedActionCount: accepted.length,
        missedSafetyChecks,
    };
}
