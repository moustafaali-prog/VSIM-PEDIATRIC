"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditLog = void 0;
class AuditLog {
    entries = [];
    append(entry) { this.entries.push({ ...entry }); }
    clear() { this.entries = []; }
    snapshot() { return [...this.entries]; }
    all() { return this.snapshot(); }
    actionRecords() { return this.entries.filter(e => e.type === "action" && e.action).map(e => ({ ...e.action })); }
}
exports.AuditLog = AuditLog;
