"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.evaluateCompletion = evaluateCompletion;
const SBARForm_1 = require("../ui/SBARForm");
function evaluateCompletion(state, audit, sbar) {
    const accepted = new Set(audit.filter(e => e.type === "action" && e.action?.accepted).map(e => e.action.actionId));
    const safetyGateComplete = state.audit.handHygieneCompleted && state.audit.patientIdentified && state.audit.allergyCheckCompleted;
    const initialAssessmentComplete = ["review_ehr", "initial_vitals", "pat_assessment"].every(x => accepted.has(x));
    const reassessmentComplete = accepted.has("reassess_vitals") || accepted.has("reassess_neuro");
    const documentationComplete = accepted.has("document");
    const sbarComplete = accepted.has("sbar_handover") && (!sbar || (0, SBARForm_1.isCompleteSBAR)(sbar));
    const blockers = [];
    if (!safetyGateComplete)
        blockers.push("SAFETY_GATE_INCOMPLETE");
    if (!initialAssessmentComplete)
        blockers.push("INITIAL_ASSESSMENT_INCOMPLETE");
    if (!reassessmentComplete)
        blockers.push("REASSESSMENT_INCOMPLETE");
    if (!documentationComplete)
        blockers.push("DOCUMENTATION_INCOMPLETE");
    if (!sbarComplete)
        blockers.push("SBAR_INCOMPLETE");
    return { safetyGateComplete, initialAssessmentComplete, reassessmentComplete, documentationComplete, sbarComplete, readyForDebrief: blockers.length === 0, blockers };
}
