"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EndToEndSession = void 0;
const SimulationRuntime_1 = require("./SimulationRuntime");
const ScenarioEHRBridge_1 = require("../ehr/ScenarioEHRBridge");
const SimulationCompletion_1 = require("./SimulationCompletion");
const DebriefEngine_1 = require("../debrief/DebriefEngine");
/** One session boundary: clinical runtime + EHR projection + completion/debrief. */
class EndToEndSession {
    runtime;
    ehr;
    sbar;
    constructor(scenario) {
        this.runtime = new SimulationRuntime_1.SimulationRuntime(scenario);
        this.ehr = "catalog" in scenario ? (0, ScenarioEHRBridge_1.createScenarioEHR)(scenario) : null;
    }
    start() { this.runtime.start(); }
    pause() { this.runtime.pause(); }
    tick(deltaSeconds) {
        const snapshot = this.runtime.tick(deltaSeconds);
        if (this.ehr)
            (0, ScenarioEHRBridge_1.appendRuntimeVitals)(this.ehr, snapshot.state);
        return this.snapshot();
    }
    perform(actionId, note, target) {
        return this.runtime.perform(actionId, note, target);
    }
    setSBAR(form) { this.sbar = { ...form }; }
    snapshot() {
        const base = this.runtime.snapshot();
        const entries = this.runtime.controller.audit.all();
        return {
            ...base,
            ehr: this.ehr ? (0, ScenarioEHRBridge_1.snapshotEHR)(this.ehr) : { patient: { id: "", displayName: "", ageYears: 0, weightKg: 0, allergies: [], diagnosis: "" }, vitals: [], labs: [], orders: [], notes: [] },
            completion: (0, SimulationCompletion_1.evaluateCompletion)(base.state, entries, this.sbar),
        };
    }
    debrief() {
        const c = this.runtime.controller;
        return (0, DebriefEngine_1.buildDebrief)(c.getState(), c.audit, c.assessment.performance, c.assessment.cjmm);
    }
    reset(scenario) {
        this.runtime.reset(scenario);
        this.ehr = "catalog" in scenario ? (0, ScenarioEHRBridge_1.createScenarioEHR)(scenario) : null;
        this.sbar = undefined;
    }
}
exports.EndToEndSession = EndToEndSession;
