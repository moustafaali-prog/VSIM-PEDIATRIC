"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SimulationClock = void 0;
class SimulationClock {
    elapsed = 0;
    running = false;
    start() { this.running = true; }
    pause() { this.running = false; }
    reset() { this.elapsed = 0; this.running = false; }
    update(deltaSeconds) {
        if (!Number.isFinite(deltaSeconds) || deltaSeconds < 0)
            throw new Error("Invalid simulation delta.");
        if (this.running)
            this.elapsed += deltaSeconds;
    }
    get timeSeconds() { return this.elapsed; }
}
exports.SimulationClock = SimulationClock;
