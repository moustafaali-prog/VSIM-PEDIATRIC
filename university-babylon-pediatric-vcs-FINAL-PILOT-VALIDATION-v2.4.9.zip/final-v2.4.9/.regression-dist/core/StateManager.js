"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StateManager = void 0;
class StateManager {
    state;
    constructor(initialState) { this.state = initialState; }
    getState() { return this.state; }
    mutableState() { return this.state; }
    update(updater) { updater(this.state); }
    replace(next) { this.state = next; }
}
exports.StateManager = StateManager;
