"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SimulationController = void 0;
const StateManager_1 = require("./StateManager");
const SimulationClock_1 = require("./SimulationClock");
const SafetyEngine_1 = require("./SafetyEngine");
const ScenarioEngine_1 = require("../scenarios/ScenarioEngine");
const AuditLog_1 = require("../audit/AuditLog");
const CJMMEngine_1 = require("../assessment/CJMMEngine");
const PerformanceScoringEngine_1 = require("../assessment/PerformanceScoringEngine");
const IntegratedAssessmentEngine_1 = require("../assessment/IntegratedAssessmentEngine");
class SimulationController {
    clock = new SimulationClock_1.SimulationClock();
    state;
    audit = new AuditLog_1.AuditLog();
    cjmm = new CJMMEngine_1.CJMMEngine();
    performance = new PerformanceScoringEngine_1.PerformanceScoringEngine();
    scenarioEngine;
    safety;
    assessment;
    constructor(scenario, safety = new SafetyEngine_1.SafetyEngine()) {
        this.safety = safety;
        this.state = new StateManager_1.StateManager(structuredClone(scenario.initialState));
        this.scenarioEngine = new ScenarioEngine_1.ScenarioEngine(scenario);
        this.assessment = new IntegratedAssessmentEngine_1.IntegratedAssessmentEngine(scenario.id);
    }
    start() { this.clock.start(); }
    pause() { this.clock.pause(); }
    reset(scenario) {
        this.clock.reset();
        this.state.replace(structuredClone(scenario.initialState));
        this.scenarioEngine.setScenario(scenario);
        this.assessment = new IntegratedAssessmentEngine_1.IntegratedAssessmentEngine(scenario.id);
        this.audit.clear();
    }
    update(deltaSeconds) {
        this.clock.update(deltaSeconds);
        this.state.update(s => { s.timeSeconds = this.clock.timeSeconds; });
        this.scenarioEngine.tick(this.state.mutableState());
    }
    performAction(actionId, note, target) {
        const ctx = { actionId, simulationTimeSeconds: this.clock.timeSeconds, note, target };
        const result = this.safety.evaluate(ctx, this.state.getState());
        const accepted = result.allowed;
        this.audit.append({
            timestamp: this.clock.timeSeconds,
            type: "action",
            message: accepted ? "Action accepted." : `Action blocked: ${result.reason}`,
            action: { timestamp: this.clock.timeSeconds, ...ctx, accepted, reason: result.reason },
        });
        if (accepted) {
            if (actionId === "hand_hygiene")
                this.state.update(s => { s.audit.handHygieneCompleted = true; });
            if (actionId === "identify_patient")
                this.state.update(s => { s.audit.patientIdentified = true; });
            if (actionId === "check_allergies")
                this.state.update(s => { s.audit.allergyCheckCompleted = true; });
            this.scenarioEngine.handleAction(actionId, this.state.mutableState());
            this.assessment.recordAction({ ...ctx, accepted, reason: result.reason });
        }
        return accepted;
    }
    dispatchAction(actionId) {
        return this.performAction(actionId);
    }
    getState() { return this.state.getState(); }
}
exports.SimulationController = SimulationController;
