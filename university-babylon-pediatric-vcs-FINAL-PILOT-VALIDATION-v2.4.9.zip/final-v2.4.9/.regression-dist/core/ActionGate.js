"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActionGate = void 0;
class ActionGate {
    s;
    constructor(s) {
        this.s = s;
    }
    canTouchPatient(a) {
        const safe = ["hand_hygiene", "identify_patient", "check_allergies"];
        if (safe.includes(a))
            return true;
        return this.s.handHygieneCompleted && this.s.patientIdentified && this.s.allergiesChecked;
    }
    record(a) {
        if (a === "hand_hygiene")
            this.s.handHygieneCompleted = true;
        if (a === "identify_patient")
            this.s.patientIdentified = true;
        if (a === "check_allergies")
            this.s.allergiesChecked = true;
    }
}
exports.ActionGate = ActionGate;
