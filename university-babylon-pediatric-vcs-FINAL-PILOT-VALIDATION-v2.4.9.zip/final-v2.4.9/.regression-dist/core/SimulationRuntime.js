"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SimulationRuntime = void 0;
const SimulationController_1 = require("./SimulationController");
/** Single orchestration boundary for UI, scene, telemetry and assessment. */
class SimulationRuntime {
    controller;
    constructor(scenario) {
        this.controller = new SimulationController_1.SimulationController(scenario);
    }
    start() { this.controller.start(); }
    pause() { this.controller.pause(); }
    tick(deltaSeconds) {
        this.controller.update(deltaSeconds);
        return this.snapshot();
    }
    perform(actionId, note, target) {
        return this.controller.performAction(actionId, note, target);
    }
    reset(scenario) { this.controller.reset(scenario); }
    snapshot() {
        return {
            timeSeconds: this.controller.clock.timeSeconds,
            state: this.controller.getState(),
            scenarioId: this.controller.scenarioEngine.getScenario().id,
            assessment: this.controller.assessment.snapshot(),
        };
    }
}
exports.SimulationRuntime = SimulationRuntime;
