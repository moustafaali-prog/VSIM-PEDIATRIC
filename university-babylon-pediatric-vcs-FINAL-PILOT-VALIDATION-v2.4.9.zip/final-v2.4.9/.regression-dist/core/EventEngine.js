"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventEngine = void 0;
class EventEngine {
    fired = new Set();
    process(s, events, actionId) {
        for (const e of events) {
            if (e.once && this.fired.has(e.id))
                continue;
            const ok = e.trigger.type === "time" ? s.timeSeconds >= e.trigger.atSeconds : e.trigger.actionId === actionId;
            if (ok) {
                e.execute(s);
                if (e.once)
                    this.fired.add(e.id);
            }
        }
    }
    reset() { this.fired.clear(); }
}
exports.EventEngine = EventEngine;
