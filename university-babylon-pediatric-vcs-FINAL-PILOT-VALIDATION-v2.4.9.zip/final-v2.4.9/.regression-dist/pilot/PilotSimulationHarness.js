"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPilotScenario = getPilotScenario;
exports.runPilotScenario = runPilotScenario;
exports.defaultPilotSteps = defaultPilotSteps;
exports.runDeviceMatrix = runDeviceMatrix;
exports.simulatePerformance = simulatePerformance;
const EndToEndSession_1 = require("../core/EndToEndSession");
const ScenarioPackage_1 = require("../scenarios/ScenarioPackage");
const deviceFrameBudgetMs = { DESKTOP: 16.67, TABLET: 16.67, PHONE: 16.67 };
function getPilotScenario(id) {
    const scenario = (0, ScenarioPackage_1.getOperationalScenario)(id);
    if (!scenario)
        throw new Error(`Unknown operational scenario: ${id}`);
    return scenario;
}
function runPilotScenario(scenarioId, device, fault = "NONE", steps = defaultPilotSteps(fault)) {
    const scenario = getPilotScenario(scenarioId);
    const session = new EndToEndSession_1.EndToEndSession(scenario);
    session.start();
    let accepted = 0;
    let rejected = 0;
    for (const step of steps) {
        if (step.seconds && step.seconds > 0)
            session.tick(step.seconds);
        if (step.action) {
            const ok = session.perform(step.action, step.note);
            ok ? accepted++ : rejected++;
        }
    }
    const snapshot = session.snapshot();
    const entries = session.runtime.controller.audit.all();
    return {
        scenarioId, device, fault,
        completed: snapshot.completion.readyForDebrief,
        completion: snapshot.completion,
        finalTimeSeconds: snapshot.timeSeconds,
        auditCount: entries.length,
        acceptedActions: accepted,
        rejectedActions: rejected,
        observedState: snapshot.state,
    };
}
function defaultPilotSteps(fault) {
    const safety = [];
    if (fault !== "SKIP_HAND_HYGIENE")
        safety.push({ action: "hand_hygiene" });
    if (fault !== "SKIP_PATIENT_ID")
        safety.push({ action: "identify_patient" });
    if (fault !== "SKIP_ALLERGY_CHECK")
        safety.push({ action: "check_allergies" });
    const assessmentActions = ["review_ehr", "initial_vitals", "pat_assessment", "auscultate_lungs", "reassess_vitals", "document"];
    const assessment = assessmentActions.map(action => ({ action }));
    if (fault === "WRONG_SEQUENCE")
        return [...assessment, ...safety];
    return [...safety, ...assessment];
}
function runDeviceMatrix(scenarioId, fault = "NONE") {
    return ["DESKTOP", "TABLET", "PHONE"].map(device => runPilotScenario(scenarioId, device, fault));
}
/** Deterministic engineering load model; this is not a substitute for a real device benchmark. */
function simulatePerformance(device, frames = 600, averageFrameMs) {
    const frameMs = averageFrameMs ?? deviceFrameBudgetMs[device];
    if (!Number.isFinite(frames) || frames <= 0)
        throw new Error("frames must be positive");
    if (!Number.isFinite(frameMs) || frameMs <= 0)
        throw new Error("averageFrameMs must be positive");
    const elapsedMs = frames * frameMs;
    const simulatedFps = 1000 / frameMs;
    return { device, frames, elapsedMs, simulatedFps, frameBudgetMs: deviceFrameBudgetMs[device], withinBudget: frameMs <= deviceFrameBudgetMs[device] };
}
