"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScenarioCatalog = void 0;
exports.getScenarioCatalogEntry = getScenarioCatalogEntry;
/**
 * Directory facts are transcribed from project file 05 only.
 * No additional clinical rules, doses, or event timings are inferred here.
 */
exports.ScenarioCatalog = [
    { id: "rana-kadhim", code: "BABYLON-PED-01", name: "Rana Kadhim", sex: "female", ageYears: 7, weightKg: 24, diagnosis: "Acute Asthma Exacerbation", difficulty: "Advanced / selection", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
    { id: "charlie-snow", code: "VSIM-PED-02", name: "Charlie Snow", sex: "male", ageYears: 6, weightKg: 21.5, diagnosis: "Acute Asthma Exacerbation", difficulty: "Core", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
    { id: "brittany-long", code: "VSIM-PED-03", name: "Brittany Long", sex: "female", ageYears: 5, weightKg: 18, diagnosis: "Sickle Cell Vaso-Occlusive Crisis", difficulty: "Core / Complex", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
    { id: "eva-madison", code: "VSIM-PED-01", name: "Eva Madison", sex: "female", ageYears: 5, weightKg: 17.2, diagnosis: "Dehydration & Gastroenteritis", difficulty: "Core", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
    { id: "jackson-weber", code: "VSIM-PED-04", name: "Jackson Weber", sex: "male", ageYears: 3, weightKg: 14.5, diagnosis: "Generalized Tonic-Clonic Seizures", difficulty: "Complex", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
    { id: "sabrina-vasquez", code: "VSIM-PED-05", name: "Sabrina Vasquez", sex: "female", ageYears: 9, weightKg: 28, diagnosis: "Pediatric Pneumonia & Sepsis", difficulty: "Complex", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
    { id: "ethan-williams", code: "VSIM-PED-08", name: "Ethan Williams", sex: "male", ageYears: 6, weightKg: 22, diagnosis: "Post-Op Tonsillectomy Hemorrhage", difficulty: "Emergency", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
    { id: "olivia-jones", code: "VSIM-PED-09", name: "Olivia Jones", sex: "female", ageYears: 7, weightKg: 23.5, diagnosis: "Severe Pediatric Anaphylactic Shock", difficulty: "Emergency", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
    { id: "sarah-davis", code: "VSIM-PED-10", name: "Sarah Davis", sex: "female", ageYears: 2, weightKg: 11.2, diagnosis: "Tetralogy of Fallot - Tet Spell", difficulty: "Critical Cardiac", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
    { id: "tommy-evans", code: "VSIM-PED-06", name: "Tommy Evans", sex: "male", ageYears: 8, weightKg: 26, diagnosis: "Closed Head Injury & Elevated ICP", difficulty: "Neuro ICU", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
    { id: "peyton-harris", code: "VSIM-PED-07", name: "Peyton Harris", sex: "male", ageYears: 4, weightKg: 16.5, diagnosis: "Acute Bacterial Pneumonia", difficulty: "Complex", source: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" },
];
function getScenarioCatalogEntry(id) {
    return exports.ScenarioCatalog.find(s => s.id === id);
}
