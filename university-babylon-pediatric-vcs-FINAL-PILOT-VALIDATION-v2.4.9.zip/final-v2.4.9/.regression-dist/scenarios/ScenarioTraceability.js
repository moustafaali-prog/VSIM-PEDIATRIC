"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildScenarioTraceability = buildScenarioTraceability;
exports.assertScenarioTraceability = assertScenarioTraceability;
const ScenarioCatalog_1 = require("./ScenarioCatalog");
const ScenarioPackage_1 = require("./ScenarioPackage");
const ScenarioClinicalMap_1 = require("./ScenarioClinicalMap");
function buildScenarioTraceability() {
    return ScenarioCatalog_1.ScenarioCatalog.map((entry) => {
        const pkg = ScenarioPackage_1.OperationalScenarioPackages.find(s => s.catalog.id === entry.id);
        const map = (0, ScenarioClinicalMap_1.getScenarioClinicalMap)(entry.id);
        if (!pkg || !map)
            throw new Error(`TRACEABILITY_GAP:${entry.id}`);
        return {
            scenarioId: entry.id,
            code: entry.code,
            patient: entry.name,
            source: entry.source,
            sourceFacts: pkg.sourceFacts.length,
            criteria: map.criteria.length,
            sourceSupportedCriteria: map.criteria.filter(c => c.validationStatus === "SOURCE_SUPPORTED").length,
            pendingCriteria: map.criteria.filter(c => c.validationStatus === "PENDING_CLINICAL_VALIDATION").length,
            timedEvents: pkg.events.filter(e => e.trigger.type === "time").length,
            executableMedicationLogic: false,
            clinicalValidationRequired: true,
        };
    });
}
function assertScenarioTraceability() {
    const rows = buildScenarioTraceability();
    if (rows.length !== 11)
        throw new Error(`EXPECTED_11_SCENARIOS:${rows.length}`);
    const codes = new Set(rows.map(r => r.code));
    if (codes.size !== 11)
        throw new Error("DUPLICATE_SCENARIO_CODES");
    for (const row of rows) {
        if (row.sourceFacts < 1)
            throw new Error(`NO_SOURCE_FACTS:${row.scenarioId}`);
        if (row.criteria < 1)
            throw new Error(`NO_ASSESSMENT_CRITERIA:${row.scenarioId}`);
        if (!row.clinicalValidationRequired)
            throw new Error(`VALIDATION_GATE_MISSING:${row.scenarioId}`);
        if (row.executableMedicationLogic)
            throw new Error(`MEDICATION_EXECUTION_UNEXPECTED:${row.scenarioId}`);
    }
}
