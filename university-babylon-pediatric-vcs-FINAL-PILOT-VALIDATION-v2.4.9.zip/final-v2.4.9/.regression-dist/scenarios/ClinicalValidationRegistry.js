"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClinicalValidationRegistry = void 0;
exports.getClinicalValidationRecords = getClinicalValidationRecords;
exports.isScenarioClinicallyApproved = isScenarioClinicallyApproved;
exports.assertExecutableMedicationSafety = assertExecutableMedicationSafety;
const scenarios = [
    "rana-kadhim", "charlie-snow", "brittany-long", "eva-madison", "jackson-weber",
    "sabrina-vasquez", "ethan-williams", "olivia-jones", "sarah-davis", "tommy-evans", "peyton-harris"
];
const records = scenarios.flatMap((scenarioId) => [
    {
        scenarioId,
        elementId: `${scenarioId.toUpperCase()}-DEMOGRAPHICS`,
        elementType: "DEMOGRAPHICS",
        sourceDocument: "FILE-05",
        implementationRef: "src/scenarios/ScenarioCatalog.ts",
        status: "SOURCE_TRANSCRIPTION",
        executable: false,
        reviewNote: "Age, weight, diagnosis and scenario identity are transcribed from FILE-05; clinical approval is pending."
    },
    {
        scenarioId,
        elementId: `${scenarioId.toUpperCase()}-BASELINE`,
        elementType: "BASELINE_STATE",
        sourceDocument: "FILE-05",
        implementationRef: "src/scenarios/ScenarioPackage.ts",
        status: "SOURCE_TRANSCRIPTION",
        executable: false,
        reviewNote: "Baseline physiologic values are preserved from the project source and require clinical review before certification."
    },
    {
        scenarioId,
        elementId: `${scenarioId.toUpperCase()}-CRITERIA`,
        elementType: "ASSESSMENT",
        sourceDocument: "FILE-04",
        implementationRef: "src/scenarios/ScenarioClinicalMap.ts",
        status: "SOURCE_TRANSCRIPTION",
        executable: false,
        reviewNote: "Assessment/scoring criteria are project-defined and remain subject to simulation-design and clinical SME review."
    },
    {
        scenarioId,
        elementId: `${scenarioId.toUpperCase()}-MEDICATIONS`,
        elementType: "MEDICATION",
        sourceDocument: "FILE-05",
        implementationRef: "src/scenarios/ScenarioPackage.ts",
        status: "REQUIRES_REVISION",
        executable: false,
        reviewNote: "Medication/order execution is intentionally disabled until medication, dose, route, timing and contraindication logic are clinically validated."
    }
]);
exports.ClinicalValidationRegistry = records;
function getClinicalValidationRecords(scenarioId) {
    return exports.ClinicalValidationRegistry.filter((record) => record.scenarioId === scenarioId);
}
function isScenarioClinicallyApproved(scenarioId) {
    const rows = getClinicalValidationRecords(scenarioId);
    return rows.length > 0 && rows.every((row) => row.status === "SME_APPROVED");
}
function assertExecutableMedicationSafety() {
    const medicationRows = exports.ClinicalValidationRegistry.filter((row) => row.elementType === "MEDICATION");
    if (medicationRows.some((row) => row.executable || row.status === "SME_APPROVED")) {
        throw new Error("MEDICATION_EXECUTION_REQUIRES_EXPLICIT_VALIDATED_ORDER_SET");
    }
}
