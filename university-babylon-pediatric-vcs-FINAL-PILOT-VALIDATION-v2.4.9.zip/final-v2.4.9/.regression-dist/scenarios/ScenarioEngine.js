"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScenarioEngine = void 0;
class ScenarioEngine {
    fired = new Set();
    scenario;
    constructor(scenario) { this.scenario = scenario; }
    setScenario(scenario) {
        this.scenario = scenario;
        this.reset();
    }
    getScenario() { return this.scenario; }
    reset() { this.fired.clear(); }
    tick(state) {
        for (const event of this.scenario.events) {
            if (event.once && this.fired.has(event.id))
                continue;
            if (event.trigger.type === "time" && state.timeSeconds >= event.trigger.atSeconds) {
                event.execute(state);
                if (event.once)
                    this.fired.add(event.id);
            }
        }
    }
    handleAction(actionId, state) {
        const action = this.scenario.actions[actionId];
        if (action)
            action(state);
        for (const event of this.scenario.events) {
            if (event.once && this.fired.has(event.id))
                continue;
            if (event.trigger.type === "action" && event.trigger.actionId === actionId) {
                event.execute(state);
                if (event.once)
                    this.fired.add(event.id);
            }
        }
    }
}
exports.ScenarioEngine = ScenarioEngine;
