"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrittanyLongCore = void 0;
exports.BrittanyLongCore = {
    id: "VSIM-PED-03", title: "Brittany Long — Core", version: "0.2.0", validationStatus: "SCENARIO_SPECIFIC",
    patient: { id: "BRITTANY-LONG", name: "Brittany Long", ageYears: { value: 5, unit: "years", source: "SCENARIO_SPECIFIC", sourceId: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" }, weightKg: { value: 18, unit: "kg", source: "SCENARIO_SPECIFIC", sourceId: "FILE-05", validationStatus: "SCENARIO_SPECIFIC" } },
    initialState: { timeSeconds: 0, respiratory: { rate: 30, oxygenSaturation: 91, effort: "increased", airflow: "normal" }, cardiovascular: { heartRate: 135, systolicBP: 102, diastolicBP: 62, capillaryRefillSeconds: 3.5 }, pain: { score: 9, scale: "project-specified" }, hydration: { status: "possible_deficit" }, temperatureC: 38.4, position: "supine", flags: { sickleCellDisease: true, acutePainCrisis: true, acuteChestSyndrome: false }, audit: { handHygieneCompleted: false, patientIdentified: false, allergyCheckCompleted: false } },
    learningObjectives: ["Apply safety gate.", "Recognize and reassess deterioration.", "Use structured clinical judgment.", "Document and communicate with SBAR."],
    actions: {
        review_ehr: s => { s.flags.ehrReviewed = true; }, hand_hygiene: s => { s.audit.handHygieneCompleted = true; }, identify_patient: s => { s.audit.patientIdentified = true; }, check_allergies: s => { s.audit.allergyCheckCompleted = true; },
        initial_vitals: s => { s.flags.initialVitalsCompleted = true; }, pat_assessment: s => { s.flags.patCompleted = true; }, auscultate_lungs: s => { s.flags.lungAssessmentCompleted = true; }, auscultate_heart: s => { s.flags.heartAssessmentCompleted = true; }, pupil_exam: s => { s.flags.pupilExamCompleted = true; }, capillary_refill: s => { s.flags.capillaryRefillCompleted = true; }, position_high_fowler: s => { s.position = "high_fowler"; }, apply_oxygen: s => { s.flags.oxygenApplied = true; }, start_nebulizer: s => { s.flags.nebulizerStarted = true; }, reassess_vitals: s => { s.flags.reassessmentCompleted = true; }, document: s => { s.flags.documentationCompleted = true; }, sbar_handover: s => { s.flags.sbarCompleted = true; }
    },
    events: [{ id: "BL-CORE-ACS-CURVEBALL", once: true, trigger: { type: "time", atSeconds: 300 }, execute: s => { s.flags.acuteChestSyndrome = true; s.respiratory.effort = "severe"; s.respiratory.airflow = "reduced"; } }]
};
