"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getOperationalScenario = exports.SCENARIO_REGISTRY = void 0;
const ScenarioPackage_1 = require("./ScenarioPackage");
Object.defineProperty(exports, "getOperationalScenario", { enumerable: true, get: function () { return ScenarioPackage_1.getOperationalScenario; } });
exports.SCENARIO_REGISTRY = ScenarioPackage_1.OperationalScenarioPackages;
