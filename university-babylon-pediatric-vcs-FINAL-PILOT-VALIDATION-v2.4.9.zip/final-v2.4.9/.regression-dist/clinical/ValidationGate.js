"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireVerified = requireVerified;
function requireVerified(c) { if (c.status !== 'VERIFIED')
    throw new Error(`Clinical constant ${c.id} is not verified.`); }
