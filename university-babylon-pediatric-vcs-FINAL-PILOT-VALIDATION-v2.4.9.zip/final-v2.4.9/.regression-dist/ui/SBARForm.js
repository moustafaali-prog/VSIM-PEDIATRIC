"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isCompleteSBAR = isCompleteSBAR;
function isCompleteSBAR(form) {
    return [form.situation, form.background, form.assessment, form.recommendation]
        .every(value => value.trim().length > 0);
}
