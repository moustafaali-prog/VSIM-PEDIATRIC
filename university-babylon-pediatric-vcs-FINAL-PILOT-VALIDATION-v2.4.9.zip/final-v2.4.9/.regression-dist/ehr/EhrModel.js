"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EHRStore = void 0;
class EHRStore {
    patient;
    labs;
    orders;
    vitals = [];
    notes = [];
    constructor(patient, labs = [], orders = []) {
        this.patient = patient;
        this.labs = labs;
        this.orders = orders;
    }
    addVitals(v) { this.vitals.push({ ...v }); }
    addNote(n) { this.notes.push(n); }
    snapshot() { return { patient: this.patient, vitals: [...this.vitals], labs: [...this.labs], orders: [...this.orders], notes: [...this.notes] }; }
}
exports.EHRStore = EHRStore;
