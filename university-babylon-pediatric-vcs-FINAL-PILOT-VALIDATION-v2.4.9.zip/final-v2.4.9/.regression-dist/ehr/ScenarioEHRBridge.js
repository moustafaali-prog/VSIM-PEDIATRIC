"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createScenarioEHR = createScenarioEHR;
exports.projectVitals = projectVitals;
exports.appendRuntimeVitals = appendRuntimeVitals;
exports.snapshotEHR = snapshotEHR;
const EhrModel_1 = require("./EhrModel");
/** Read-only projection of source-supported scenario data into the EHR layer. */
function createScenarioEHR(scenario) {
    const patient = {
        id: scenario.patient.id,
        displayName: scenario.patient.name,
        ageYears: scenario.patient.ageYears.value,
        weightKg: scenario.patient.weightKg.value,
        allergies: scenario.sourceSupportedAllergies,
        diagnosis: scenario.catalog.diagnosis,
    };
    return new EhrModel_1.EHRStore(patient, [], []);
}
function projectVitals(state, timeSeconds) {
    return {
        timeSeconds,
        heartRate: state.cardiovascular.heartRate,
        respiratoryRate: state.respiratory.rate,
        systolicBP: state.cardiovascular.systolicBP,
        diastolicBP: state.cardiovascular.diastolicBP,
        oxygenSaturation: state.respiratory.oxygenSaturation,
        temperatureC: state.temperatureC,
    };
}
function appendRuntimeVitals(ehr, state) {
    ehr.addVitals(projectVitals(state, state.timeSeconds));
}
function snapshotEHR(ehr) { return ehr.snapshot(); }
