"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PerformanceScoringEngine = void 0;
const DEFAULT_WEIGHTS = { safety: 20, assessment: 25, interventions: 30, emergency: 15, communication: 10 };
class PerformanceScoringEngine {
    weights = DEFAULT_WEIGHTS;
    earned = { safety: 0, assessment: 0, interventions: 0, emergency: 0, communication: 0 };
    setDomainScore(domain, score) { if (!Number.isFinite(score))
        throw new Error('Score must be finite'); this.earned[domain] = Math.max(0, Math.min(this.weights[domain], score)); }
    applyPenalty(domain, penalty) { if (!Number.isFinite(penalty) || penalty < 0)
        throw new Error('Penalty must be non-negative'); this.earned[domain] = Math.max(0, this.earned[domain] - penalty); }
    total() { return Object.values(this.earned).reduce((a, b) => a + b, 0); }
    snapshot() { return { ...this.earned }; }
}
exports.PerformanceScoringEngine = PerformanceScoringEngine;
