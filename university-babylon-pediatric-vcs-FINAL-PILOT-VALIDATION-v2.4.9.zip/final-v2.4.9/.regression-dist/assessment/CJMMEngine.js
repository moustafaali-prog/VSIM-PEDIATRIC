"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CJMMEngine = void 0;
const WEIGHTS = {
    recognize_cues: 15, analyze_cues: 15, prioritize_hypotheses: 15,
    generate_solutions: 15, take_action: 25, evaluate_outcomes: 15,
};
class CJMMEngine {
    scores = new Map();
    constructor() {
        Object.keys(WEIGHTS).forEach((s) => this.scores.set(s, 0));
    }
    record(stage, points) {
        this.scores.set(stage, Math.max(0, Math.min(WEIGHTS[stage], points)));
    }
    getScores() {
        return Object.keys(WEIGHTS).map((stage) => ({
            stage, earned: this.scores.get(stage) ?? 0, possible: WEIGHTS[stage],
        }));
    }
    total() {
        return this.getScores().reduce((sum, x) => sum + x.earned, 0);
    }
}
exports.CJMMEngine = CJMMEngine;
