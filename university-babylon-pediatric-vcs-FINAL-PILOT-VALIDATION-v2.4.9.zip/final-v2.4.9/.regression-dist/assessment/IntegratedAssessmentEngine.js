"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntegratedAssessmentEngine = void 0;
const CJMMEngine_1 = require("./CJMMEngine");
const PerformanceScoringEngine_1 = require("./PerformanceScoringEngine");
const ScenarioClinicalMap_1 = require("../scenarios/ScenarioClinicalMap");
/**
 * Scenario-aware assessment adapter.
 * Scores are normalized inside each domain/stage, then mapped to the weights
 * already defined by FILE-04/FILE-07. Pending clinical-validation criteria
 * are deliberately excluded from the denominator so they cannot silently
 * distort a student's grade.
 */
class IntegratedAssessmentEngine {
    performance = new PerformanceScoringEngine_1.PerformanceScoringEngine();
    cjmm = new CJMMEngine_1.CJMMEngine();
    map;
    completed = new Set();
    constructor(scenarioId) { this.map = (0, ScenarioClinicalMap_1.getScenarioClinicalMap)(scenarioId); }
    recordAction(record) {
        if (!record.accepted || !this.map)
            return;
        for (const c of this.map.criteria) {
            if (c.actionId !== record.actionId || this.completed.has(c.id) || c.validationStatus !== "SOURCE_SUPPORTED")
                continue;
            this.completed.add(c.id);
            this.recalculate();
        }
    }
    recalculate() {
        if (!this.map)
            return;
        const domains = ["safety", "assessment", "interventions", "emergency", "communication"];
        for (const domain of domains) {
            const eligible = this.map.criteria.filter(c => c.domain === domain && c.validationStatus === "SOURCE_SUPPORTED");
            const possible = eligible.reduce((n, c) => n + c.points, 0);
            const earned = eligible.filter(c => this.completed.has(c.id)).reduce((n, c) => n + c.points, 0);
            const max = this.performance.weights[domain];
            this.performance.setDomainScore(domain, possible === 0 ? 0 : (earned / possible) * max);
        }
        const stages = ["recognize_cues", "analyze_cues", "prioritize_hypotheses", "generate_solutions", "take_action", "evaluate_outcomes"];
        for (const stage of stages) {
            const eligible = this.map.criteria.filter(c => c.cjmmStage === stage && c.validationStatus === "SOURCE_SUPPORTED");
            const possible = eligible.reduce((n, c) => n + c.points, 0);
            const earned = eligible.filter(c => this.completed.has(c.id)).reduce((n, c) => n + c.points, 0);
            const weight = this.cjmm.getScores().find(s => s.stage === stage).possible;
            this.cjmm.record(stage, possible === 0 ? 0 : (earned / possible) * weight);
        }
    }
    snapshot() {
        const criteria = this.map?.criteria ?? [];
        return {
            performance: this.performance.snapshot(),
            performanceTotal: Number(this.performance.total().toFixed(2)),
            cjmm: this.cjmm.getScores(),
            cjmmTotal: Number(this.cjmm.total().toFixed(2)),
            completedCriteria: [...this.completed],
            missedCriteria: criteria.filter(c => !this.completed.has(c.id) && c.validationStatus === "SOURCE_SUPPORTED").map(c => c.id),
            validationBlockedCriteria: criteria.filter(c => c.validationStatus === "PENDING_CLINICAL_VALIDATION").map(c => c.id),
        };
    }
}
exports.IntegratedAssessmentEngine = IntegratedAssessmentEngine;
