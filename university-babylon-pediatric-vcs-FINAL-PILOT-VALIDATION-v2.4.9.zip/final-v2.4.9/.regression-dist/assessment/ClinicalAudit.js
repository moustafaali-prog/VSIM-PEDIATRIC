"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.summarizeAudit = summarizeAudit;
function summarizeAudit(entries) {
    let acceptedActions = 0;
    let blockedActions = 0;
    let criticalErrors = 0;
    for (const entry of entries) {
        if (entry.type !== "action" || !entry.action)
            continue;
        if (entry.action.accepted)
            acceptedActions++;
        else
            blockedActions++;
        if (entry.action.reason)
            criticalErrors++;
    }
    return { totalActions: acceptedActions + blockedActions, acceptedActions, blockedActions, criticalErrors };
}
