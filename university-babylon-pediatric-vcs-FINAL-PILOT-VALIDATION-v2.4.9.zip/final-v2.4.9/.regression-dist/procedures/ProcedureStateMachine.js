"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcedureStateMachine = void 0;
class ProcedureStateMachine {
    state = { id: 'HAND_HYGIENE', phase: 'idle', progress: 0 };
    begin(id) { this.state = { id, phase: 'approach', progress: 0 }; }
    update(dt) { if (this.state.phase === 'idle' || this.state.phase === 'complete')
        return; if (!Number.isFinite(dt) || dt < 0)
        throw new Error('Invalid delta'); this.state.phase = 'perform'; this.state.progress = Math.min(1, this.state.progress + dt / 2); if (this.state.progress >= 1)
        this.state.phase = 'complete'; }
    cancel() { this.state.phase = 'cancelled'; }
    snapshot() { return { ...this.state }; }
}
exports.ProcedureStateMachine = ProcedureStateMachine;
