"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClinicalAudioController = void 0;
/**
 * Audio is intentionally an interface layer in v0.3.0.
 * Sound selection follows clinical state/scenario events.
 * No sound is allowed to mutate the clinical state.
 */
class ClinicalAudioController {
    enabled = true;
    active = new Set();
    setEnabled(enabled) {
        this.enabled = enabled;
        if (!enabled)
            this.active.clear();
    }
    setClinicalSounds(sounds) {
        if (!this.enabled) {
            this.active.clear();
            return;
        }
        this.active = new Set(sounds);
    }
    snapshot() {
        return {
            enabled: this.enabled,
            activeSounds: [...this.active],
        };
    }
}
exports.ClinicalAudioController = ClinicalAudioController;
