# Deployment Guide

## Development
1. Install a current Node.js LTS release.
2. Run `npm install`.
3. Run `npm run build`.
4. Serve the project through an HTTPS development server for browser APIs.
5. Run the browser application and test desktop, tablet and smartphone pointer interactions.

## Clinical validation before institutional deployment
- Approve each scenario through the College/clinical governance process.
- Validate medication/order-set data independently.
- Validate scenario timing, scoring, safety gates and debriefing with subject-matter experts.
- Conduct usability and accessibility testing.
- Benchmark representative desktop, tablet and smartphone devices.

## Data protection
Do not place real patient-identifying information in the simulation dataset. Use fictional or de-identified educational cases.
