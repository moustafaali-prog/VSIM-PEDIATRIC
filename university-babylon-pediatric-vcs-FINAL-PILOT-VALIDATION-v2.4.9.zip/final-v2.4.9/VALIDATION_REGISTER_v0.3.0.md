# Validation Register — v0.3.0

## Implemented
- Clinical state → visual state projection.
- Patient visual controller.
- Raycast interaction layer.
- Clinical interaction target map based on File 06 target terminology.
- Telemetry model.
- Performance monitor.
- Audio interface layer.

## Deliberately not implemented
- Fixed physiologic bonuses for positioning.
- Universal SpO2 threshold for a "silent chest" event.
- New medication dose instructions.
- New pharmacokinetic/pharmacodynamic constants.
- Randomized vital signs.
- Automatic clinical-state mutation from visual/audio effects.

## Architectural invariant
Clinical state is authoritative. Rendering, animation, telemetry and audio consume the state; they do not create or arbitrarily overwrite it.
